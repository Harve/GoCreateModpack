==HOW TO CREATE A GO CREATE SERVER==
1. Download Go Create Server from CurseForge
2. Extract contents to a folder
3. Run start-server.bat or start-server.sh depending on your OS
4. Wait for it to download all the contents
5. Type TRUE when prompted 
6. Wait for server to start
7. Stop the server and move ftbchunks.snbt and ftbessentials.snbt to world/serverconfig folder
8. Start the server again
9. Enjoy