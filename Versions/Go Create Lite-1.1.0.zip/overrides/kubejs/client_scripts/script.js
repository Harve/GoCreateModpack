// priority: 0

console.info('Hello, World! (You will see this line every time client resources reload)')

onEvent('jei.hide.items', event => {
	 
 
  event.hide('createaddition:furnace_burner')
  event.hide('refinedstorage:basic_processor')
  event.hide('refinedstorage:improved_processor')
  event.hide('refinedstorage:advanced_processor')
  event.hide('refinedstorage:raw_basic_processor')
  event.hide('refinedstorage:raw_improved_processor')
  event.hide('refinedstorage:raw_advanced_processor')
  event.hide('refinedstorage:improved_processor')
  event.hide('twilightforest:uncrafting_table')
  event.hide('twilightforest:twilight_oak_door')
  event.hide('twilightforest:canopy_door')
  event.hide('twilightforest:mangrove_door')
  event.hide('twilightforest:dark_door')
  event.hide('twilightforest:time_door')
  event.hide('twilightforest:trans_trapdoor')
  event.hide('twilightforest:trans_door')
  event.hide('twilightforest:mine_door')
  event.hide('twilightforest:sort_door')
  event.hide('tconstruct:blank_cast')
  event.hide('tconstruct:ingot_cast')
  event.hide('tconstruct:nugget_cast')
  event.hide('tconstruct:gem_cast')
  event.hide('tconstruct:rod_cast')
  event.hide('tconstruct:repair_kit_cast')
  event.hide('tconstruct:plate_cast')
  event.hide('tconstruct:pickaxe_head_cast')
  event.hide('tconstruct:small_axe_head_cast')
  event.hide('tconstruct:small_blade_cast')
  event.hide('tconstruct:hammer_head_cast')
  event.hide('tconstruct:broad_blade_cast')
  event.hide('tconstruct:broad_axe_head_cast')
  event.hide('tconstruct:tool_binding_cast')
  event.hide('tconstruct:large_plate_cast')
  event.hide('tconstruct:tool_handle_cast')
  event.hide('tconstruct:tough_tool_handle_cast')
   event.hide('tconstruct:tough_handle_cast')
  event.hide('extradisks:infinite_storage_block')
  event.hide('extradisks:infinite_storage_part')
  event.hide('extradisks:infinite_storage_disk')
  event.hide('extradisks:infinite_fluid_storage_block')
  event.hide('extradisks:infinite_fluid_storage_part')
  event.hide('extradisks:infinite_storage_disk')
  event.hide('enderstorage:ender_pouch')
  event.hide('refinedstorage:quartz_enriched_iron_block')
	event.hide('tconstruct:copper_ore')
	event.hide('createdeco:zinc_sheet')
  

  
 
  event.hide('betterendforge:pearlberry_seed')
  	  var abyssTools = ['create_stuff_additions:encased_jet_chestplate']
	  abyssTools.forEach((tool)=>{
		  event.hide(Item.of(tool).ignoreNBT())
	  })
 
   })

   onEvent('partial.registry.drillhead', event => {
    // the first argument is your item's id, and then your model's location. in this case it will have to be in 
    // assets/kubejs/models/block/test_item
    event.create("kubejs:gotopium_drillhead", "kubejs:block/gotopium_drillhead")
})