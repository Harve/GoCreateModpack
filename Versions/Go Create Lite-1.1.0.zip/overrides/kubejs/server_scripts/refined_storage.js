// priority: 0

settings.logAddedRecipes = true
settings.logRemovedRecipes = true
settings.logSkippedRecipes = false
settings.logErroringRecipes = true


onEvent('recipes', event => {
	//REFINED STORAGE CHANGES
	event.remove({output:'refinedstorage:quartz_enriched_iron_block'})
	 event.replaceInput({}, 'refinedstorage:quartz_enriched_iron', 'kubejs:storagium_ingot')
	 event.replaceInput({}, 'refinedstorage:advanced_processor', 'kubejs:advanced_circuit')
	 event.replaceInput({}, 'refinedstorage:improved_processor', 'kubejs:integrated_circuit')
	  event.replaceInput({}, 'refinedstorage:basic_processor', 'create:electron_tube')
	   event.replaceInput({output:'refinedstorage:controller'}, 'refinedstorage:machine_casing', 'storagedrawers:controller')
	 event.remove({id:'refinedstorage:basic_processor'})
	  event.remove({id:'refinedstorage:improved_processor'})
	 event.remove({id:'refinedstorage:advanced_processor'})
	  event.remove({id:'refinedstorage:raw_basic_processor'})
	  event.remove({id:'refinedstorage:raw_improved_processor'})
	 event.remove({id:'refinedstorage:raw_advanced_processor'})
	
	
	event.remove({id:'creativewirelesstransmitter:creative_wireless_transmitter'})
	 event.shaped('creativewirelesstransmitter:creative_wireless_transmitter', [
	'CAC',
	'UUU',
	'CAC'],{
		A: 'kubejs:microprocessor',
		
		C: 'refinedstorage:wireless_transmitter',
		U: 'refinedstorage:range_upgrade'
	
	})
	
	
	 event.shaped('refinedstorageaddons:creative_wireless_crafting_grid', [
	' I ',
	' A ',
	' R '],{
		A: 'kubejs:microprocessor',
		
		R: 'refinedstorageaddons:wireless_crafting_grid',
		I: 'betterendforge:aeternium_ingot'
	
	})
	
	event.shaped('refinedstorage:creative_wireless_crafting_monitor', [
	' I ',
	' A ',
	' R '],{
		A: 'kubejs:microprocessor',
		
		R: 'refinedstorage:wireless_crafting_monitor',
		I: 'betterendforge:aeternium_ingot'
	
	})
	event.replaceInput({output: 'refinedstorage:security_card'}, 'kubejs:advanced_circuit', 'create:electron_tube')
	 event.replaceInput({output: 'refinedstorage:network_card'}, 'kubejs:advanced_circuit', 'create:electron_tube')
	//EXTRA DISKS
	event.replaceInput({mod:'extradisks'}, 'kubejs:storagium_ingot', 'kubejs:storegalium_ingot')
	event.replaceInput({mod:'extradisks'}, 'kubejs:advanced_circuit', 'kubejs:basic_storage_processor')
	event.replaceInput({mod:'extradisks'}, 'kubejs:integrated_circuit', 'kubejs:advanced_circuit')
	
	 event.recipes.create.mechanical_crafting('kubejs:basic_storage_processor',[
	
	'  T  ',
	'TCACT',
	' WWW '],{
		T:'minecraft:obsidian',
		C:'kubejs:advanced_circuit',
		A:'refinedstorage:4k_storage_part',
	W:'kubejs:storegalium_ingot'})
	
	 var refinedTypes = ['block','part','disk']
	 refinedTypes.forEach((type) =>{
		 event.remove({output:'extradisks:infinite_storage_'+type})
		 event.remove({output:'extradisks:infinite_fluid_storage_'+type})
	 })
	 
	   event.recipes.create.sequenced_assembly([
  Item.of('kubejs:advanced_storage_processor').withChance(100.0)], 'kubejs:basic_storage_processor', [
  event.recipes.create.cutting('kubejs:incomplete_advanced_storage_processor', 'kubejs:incomplete_advanced_storage_processor').processingTime(60),
  event.recipes.create.deploying('kubejs:incomplete_advanced_storage_processor', ['kubejs:incomplete_advanced_storage_processor', 'tconstruct:manyullyn_ingot']),
  event.recipes.create.filling('kubejs:incomplete_advanced_storage_processor', ['kubejs:incomplete_advanced_storage_processor',Fluid.of('kubejs:molten_silicon', 250)]),
  event.recipes.create.deploying('kubejs:incomplete_advanced_storage_processor', ['kubejs:incomplete_advanced_storage_processor', 'kubejs:gotopium_sheet']),
  event.recipes.create.pressing('kubejs:incomplete_advanced_storage_processor',['kubejs:incomplete_advanced_storage_processor'])
]).transitionalItem('kubejs:incomplete_advanced_storage_processor').loops(3)

var tier2Disks = ['4096','16384','65536']
	tier2Disks.forEach((size)=>{
		event.replaceInput({output:'extradisks:'+size+'k_storage_part'}, 'kubejs:basic_storage_processor', 'kubejs:advanced_storage_processor')
	})
	
	 event.recipes.create.mechanical_crafting('kubejs:dedicated_storage_device',[
	'RRRRR',
	'RAMAR',
	'RMGMR',
	'RAMAR',
	'RRRRR'],{
		R:'create:refined_radiance',
		M:'kubejs:microprocessor',
		A:'kubejs:advanced_storage_processor',
	G:'kubejs:gotopium_block'})
	event.replaceInput({output:'extradisks:262144k_storage_part'}, 'extradisks:withering_processor', 'kubejs:advanced_storage_processor')
	event.replaceInput({output:'extradisks:262144k_storage_part'}, 'minecraft:redstone', 'kubejs:dedicated_storage_device')
	event.replaceInput({output:'extradisks:1048576k_storage_part'}, 'extradisks:withering_processor', 'kubejs:dedicated_storage_device')
	event.replaceInput({output:'extradisks:1048576k_storage_part'}, 'minecraft:redstone', 'kubejs:go_energy_green')
	event.replaceInput({output:'extradisks:1048576k_fluid_storage_part'}, 'extradisks:withering_processor', 'kubejs:advanced_storage_processor')
})






