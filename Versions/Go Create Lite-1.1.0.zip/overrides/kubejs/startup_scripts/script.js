// priority: 0

console.info('Hello, World! (You will only see this line once in console, during startup)')

onEvent('item.registry', event => {
	// Register new items here
	//event.create('example_item').displayName('Example Item')
	//CUSTOM CREATE ITEMS
	event.create('blazing_sugar').displayName('Blazing Sugar')
	event.create('advanced_circuit').displayName('§cAdvanced Circuit')
	event.create('microprocessor').displayName('§dMicroprocessor')
	event.create('silicon_blend').displayName('Silicon Blend')
	event.create('silicon_wafer').displayName('§eSilicon Wafer').glow(true)
	
	
	event.create('storagium_ingot').displayName('Storagium Ingot')
	event.create('storagium_nugget').displayName('Storagium Nugget')
	event.create('crushed_storagium_ore').displayName('Crushed Storagium Ore')
	//CUSTOM FOODS
	event.create('drink_can').displayName('Drink Can')
	event.create('flavor_blend').displayName('Flavor Blend')	
	
	event.create('go_energy_green').food(food=>{food.hunger(6).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 180 1`); e.server.runCommandSilent(`give ${e.player} kubejs:drink_can`)})}).displayName('§aGo Energy Original')
	event.create('go_energy_blue').food(food=>{food.hunger(6).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 120 0`); e.server.runCommandSilent(`effect give ${e.player} minecraft:levitation 2 0`);e.server.runCommandSilent(`effect give ${e.player} minecraft:jump_boost 120 0`); e.server.runCommandSilent(`give ${e.player} kubejs:drink_can`)})}).displayName('§bGo Energy Diet')
	event.create('go_energy_pink').food(food=>{food.hunger(6).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 120 0`); e.server.runCommandSilent(`effect give ${e.player} minecraft:strength 120 0`);e.server.runCommandSilent(`effect give ${e.player} minecraft:regeneration 30 1`); e.server.runCommandSilent(`give ${e.player} kubejs:drink_can`)})}).displayName('§5Go Energy Mixed Berry')
	event.create('go_energy_purple').food(food=>{food.hunger(6).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 120 0`); e.server.runCommandSilent(`effect give ${e.player} minecraft:absorption 60 4`); e.server.runCommandSilent(`give ${e.player} kubejs:drink_can`)})}).displayName('§dGo Energy Chorus Punch')	
	event.create('go_energy_red').food(food=>{food.hunger(6).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 120 0`); e.server.runCommandSilent(`effect give ${e.player} minecraft:haste 180 0`); e.server.runCommandSilent(`give ${e.player} kubejs:drink_can`)})}).displayName('§eGo Energy Tea')	
	event.create('go_energy_yellow').food(food=>{food.hunger(6).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 120 0`); e.server.runCommandSilent(`effect give ${e.player} minecraft:health_boost 60 2`); e.server.runCommandSilent(`give ${e.player} kubejs:drink_can`)})}).displayName('§6Go Energy Honey Splash')	
	//1.2 ITEMS
	event.create('americano').food(food=>{food.hunger(4).saturation(0.7).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 60 1`); e.server.runCommandSilent(`give ${e.player} kubejs:empty_cup`)})}).displayName('Americano')
	event.create('apple_fritter').food(food=>{food.hunger(7).saturation(0.5)}).displayName('Apple Fritter')
	
	event.create('bottle_of_mayo').food(food=>{food.hunger(1).saturation(0.1)}).displayName('Bottle of Mayo')
	event.create('brownie').food(food=>{food.hunger(7).saturation(0.7)}).displayName('Brownie')
	event.create('caramel_brownie_mix').displayName('Caramel Brownie Mix')
	event.create('brownie_mix').displayName('Brownie Mix')
	event.create('butter').food(food=>{food.hunger(1).saturation(0.1)}).displayName('Butter')
	event.create('cappuccino').food(food=>{food.hunger(8).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 60 1`); e.server.runCommandSilent(`give ${e.player} kubejs:empty_cup`)})}).displayName('Cappuccino')
	event.create('cappuccino_caramel').food(food=>{food.hunger(10).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 60 1`); e.server.runCommandSilent(`give ${e.player} kubejs:empty_cup`)})}).displayName('Caramel Cappuccino')
	event.create('cappuccino_chocolate').food(food=>{food.hunger(10).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 06 1`); e.server.runCommandSilent(`give ${e.player} kubejs:empty_cup`)})}).displayName('Chocolate Cappuccino')
	event.create('caramel').food(food=>{food.hunger(2).saturation(0.1)}).displayName('Caramel')
	event.create('caramel_brownie').food(food=>{food.hunger(8).saturation(0.9)}).displayName('Caramel Brownie')
	event.create('caramel_milkshake').food(food=>{food.hunger(6).saturation(0.5).eaten(e=> { e.server.runCommandSilent(`give ${e.player} kubejs:tall_glass`)})}).displayName('Caramel Milkshake')
	event.create('chocolate_milkshake').food(food=>{food.hunger(6).saturation(0.5).eaten(e=> { e.server.runCommandSilent(`give ${e.player} kubejs:tall_glass`)})}).displayName('Chocolate Milkshake')
	event.create('coated_apple').displayName('Coated Apple')

	event.create('coated_chicken').displayName('Coated Chicken')
	event.create('cortado').food(food=>{food.hunger(4).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 60 1`); e.server.runCommandSilent(`give ${e.player} kubejs:empty_espresso_cup`)})}).displayName('Cortado')
	event.create('croissant').food(food=>{food.hunger(6).saturation(0.4)}).displayName('Croissant')
	event.create('croissant_pastry').displayName('Croissant Pastry')
	event.create('crushed_ice').displayName('Crushed Ice')
	event.create('donut').food(food=>{food.hunger(5).saturation(0.4)}).displayName('Donut')
	event.create('empty_cup').displayName('Empty Cup')
	event.create('empty_espresso_cup').displayName('Empty Espresso Cup')
	event.create('espresso').food(food=>{food.hunger(3).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 60 2`); e.server.runCommandSilent(`give ${e.player} kubejs:empty_espresso_cup`)})}).displayName('Espresso')
	event.create('flapjack').food(food=>{food.hunger(5).saturation(0.4)}).displayName('Flapjack')
	event.create('fried_chicken').food(food=>{food.hunger(17).saturation(1.2)}).displayName('Fried Chicken')
	event.create('fries').food(food=>{food.hunger(6).saturation(0.5)}).displayName('Fries')
	event.create('fries_with_mayo').food(food=>{food.hunger(9).saturation(0.6)}).displayName('Fries with Mayo')
	event.create('ginger_biscuit').food(food=>{food.hunger(4).saturation(0.1)}).displayName('Ginger Biscuit')
	event.create('go_energy_fizz').food(food=>{food.hunger(6).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 120 2`); e.server.runCommandSilent(`effect give ${e.player} minecraft:levitation 2 0`); e.server.runCommandSilent(`give ${e.player} kubejs:drink_can`)})}).displayName('§aGo Energy Fizz')
	event.create('go_energy_fizz_apple').food(food=>{food.hunger(6).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 60 1`);e.server.runCommandSilent(`effect give ${e.player} minecraft:regeneration 30 1`); e.server.runCommandSilent(`effect give ${e.player} minecraft:luck 300 1`); e.server.runCommandSilent(`give ${e.player} kubejs:drink_can`)})}).displayName('§cGo Energy Fizz Apple and Berry')
	event.create('go_energy_fizz_bolloom').food(food=>{food.hunger(6).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 60 1`);e.server.runCommandSilent(`effect give ${e.player} minecraft:levitation 20 1`);e.server.runCommandSilent(`effect give ${e.player} minecraft:slow_falling 30 0`); e.server.runCommandSilent(`give ${e.player} kubejs:drink_can`)})}).displayName('§dGo Energy Fizz Jelly Juice')
	event.create('go_energy_fizz_melon').food(food=>{food.hunger(6).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 60 1`); e.server.runCommandSilent(`effect give ${e.player} minecraft:health_boost 120 3`); e.server.runCommandSilent(`give ${e.player} kubejs:drink_can`)})}).displayName('§2Go Energy Fizz Melon Mix-Up')
	event.create('go_energy_fizz_raspberry').food(food=>{food.hunger(6).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 60 1`);e.server.runCommandSilent(`effect give ${e.player} minecraft:night_vision 60 2`);e.server.runCommandSilent(`effect give ${e.player} minecraft:invisibility 60 2`); e.server.runCommandSilent(`give ${e.player} kubejs:drink_can`)})}).displayName('§3Go Energy Fizz Tree Top Taste')
	event.create('go_energy_fizz_root').food(food=>{food.hunger(6).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 60 1`); e.server.runCommandSilent(`effect give ${e.player} minecraft:haste 180 1`); e.server.runCommandSilent(`give ${e.player} kubejs:drink_can`)})}).displayName('§6Go Energy Fizz Root Beer Kick')
	event.create('ground_coffee').displayName('Ground Coffee')
	event.create('hot_chocolate').food(food=>{food.hunger(5).saturation(0.6)}).displayName('Hot Chocolate')
	event.create('ice_in_glass').displayName('Glass of Ice')
	event.create('iced_coffee').food(food=>{food.hunger(6).saturation(0.7).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 60 1`); e.server.runCommandSilent(`give ${e.player} kubejs:tall_glass`)})}).displayName('Iced Coffee')
	event.create('iced_latte').food(food=>{food.hunger(7).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 60 1`); e.server.runCommandSilent(`give ${e.player} kubejs:tall_glass`)})}).displayName('Iced Latte')
	event.create('iced_latte_caramel').food(food=>{food.hunger(9).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 60 1`); e.server.runCommandSilent(`give ${e.player} kubejs:tall_glass`)})}).displayName('Caramel Iced Latte')
	event.create('iced_latte_chocolate').food(food=>{food.hunger(9).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 60 1`); e.server.runCommandSilent(`give ${e.player} kubejs:tall_glass`)})}).displayName('Chocolate Iced Latte')
	
	event.create('latte').food(food=>{food.hunger(7).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 60 1`); e.server.runCommandSilent(`give ${e.player} kubejs:tall_glass`)})}).displayName('Latte')
	event.create('latte_caramel').food(food=>{food.hunger(9).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 60 1`); e.server.runCommandSilent(`give ${e.player} kubejs:tall_glass`)})}).displayName('Caramel Latte')
	event.create('latte_chocolate').food(food=>{food.hunger(9).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 60 1`); e.server.runCommandSilent(`give ${e.player} kubejs:tall_glass`)})}).displayName('Chocolate Latte')
	event.create('tall_glass').displayName('Tall Glass')
	event.create('millionaire_shortbread').food(food=>{food.hunger(15).saturation(0.7)}).displayName('Millionaire Shortbread')
	event.create('mocha').food(food=>{food.hunger(10).saturation(1.1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 60 1`); e.server.runCommandSilent(`give ${e.player} kubejs:empty_cup`)})}).displayName('Mocha')
	event.create('oat_mix').displayName('Oat Mix')
	event.create('pastry_dough').displayName('Pastry Dough')
	event.create('porcelain').displayName('Porcelain')
	
	event.create('shortbread').food(food=>{food.hunger(9).saturation(0.6)}).displayName('Shortbread')
	

	//1.3 Additions
	event.create('lapis_sheet').displayName('Lapis Sheet')
	event.create('integrated_circuit').displayName('Integrated Circuit')
	event.create('impure_copper_dust').displayName('Impure Copper Dust')
	event.create('impure_gold_dust').displayName('Impure Gold Dust')
	event.create('impure_iron_dust').displayName('Impure Iron Dust')
	event.create('impure_storagium_dust').displayName('Impure Storagium Dust')
	event.create('impure_zinc_dust').displayName('Impure Zinc Dust')
	event.create('impure_brass_dust').displayName('Impure Brass Dust')
	//1.4 Additions
	event.create('impure_cobalt_dust').displayName('Impure Cobalt Dust')
	event.create('impure_thallasium_dust').displayName('Impure Thallasium Dust')
	event.create('impure_storegalium_dust').displayName('Impure Imporium Dust')
	event.create('impure_gotopium_dust').displayName('Impure Gotopium Dust')

	event.create('crushed_thallasium_ore').displayName('Crushed Thallasium Ore')
	event.create('crushed_gotopium_ore').displayName('Crushed Gotopium Ore')
	event.create('crushed_cobalt_ore').displayName('Crushed Cobalt Ore')
	
	event.create('storegalium_ingot').displayName('Imporium Ingot')
	event.create('storegalium_nugget').displayName('Imporium Nugget')
	event.create('gotopium_ingot').displayName('Gotopium Ingot')
	event.create('gotopium_nugget').displayName('Gotopium Nugget')
	event.create('basic_storage_processor').displayName('Basic Storage Processor')
	event.create('advanced_storage_processor').displayName('Advanced Storage Processor')
	event.create('incomplete_advanced_storage_processor').displayName('Incomplete Advanced Storage Processor')
	event.create('gotopium_sheet').displayName('Gotopium Sheet')
	event.create('storegalium_sheet').displayName('Imporium Sheet')
	event.create('powder_of_ender').displayName('Powder of Ender')
	event.create('enderate_crystal').displayName('Enderate Crystal')
	event.create('reinforced_drink_can').displayName('Reinforced Drink Can')
	event.create('go_energy_jungle').food(food=>{food.hunger(6).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:slow_falling 30`); e.server.runCommandSilent(`effect give ${e.player} minecraft:nausea 10`);  e.server.runCommandSilent(`give ${e.player} kubejs:reinforced_drink_can`); e.server.runCommandSilent(`execute in gocreate:gotopia run tp ${e.player} ~ 255 ~`); e.server.runCommandSilent(`effect give ${e.player} minecraft:slow_falling 30`); })}).displayName('§eGo Energy Jungle Juice')
	event.create('go_energy_home').food(food=>{food.hunger(6).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:slow_falling 30`); e.server.runCommandSilent(`effect give ${e.player} minecraft:nausea 10`);  e.server.runCommandSilent(`give ${e.player} kubejs:reinforced_drink_can`); e.server.runCommandSilent(`execute in minecraft:overworld run tp ${e.player} ~ 255 ~`); e.server.runCommandSilent(`effect give ${e.player} minecraft:slow_falling 30`); })}).displayName('§eGo Energy Homeward Brew')
	event.create('storagium_ore_piece').displayName('Storagium Ore Piece')
	event.create('cobalt_ore_piece').displayName('Cobalt Ore Piece')
	event.create('regalium_ore_piece').displayName('Regalium Ore Piece')
	event.create('drill_sand_cast').displayName('Drill Sand Cast')
	event.create('drill_red_sand_cast').displayName('Drill Red Sand Cast')
	
	event.create('incomplete_drill_sand_cast').type('create:sequenced_assembly').displayName('Incomplete Drill Sand Cast')
	event.create('incomplete_drill_red_sand_cast').type('create:sequenced_assembly').displayName('Incomplete Drill Red Sand Cast')

	event.create('chunkolate').food(food=>{food.hunger(3).saturation(1).eaten(e=> { e.server.runCommandSilent(`ftbchunks admin extra_force_load_chunks ${e.player} add 1`); })}).displayName('Chunkolate')
})

onEvent('block.registry', event => {
	// Register new blocks here
  
	 event.create('storagium_ore').material('rock').hardness(2.0).displayName('Storagium Ore')
	event.create('gotopium_ore').material('rock').hardness(2.0).displayName('Gotopium Ore')
    event.create('go_energy_crate').material('iron').hardness(1.0).displayName('Go Energy Original Crate')
	event.create('go_energy_blue_crate').material('iron').hardness(1.0).displayName('Go Energy Diet Crate')
	event.create('go_energy_pink_crate').material('iron').hardness(1.0).displayName('Go Energy Mixed Berry Crate')
	event.create('go_energy_purple_crate').material('iron').hardness(1.0).displayName('Go Energy Chorus Punch Crate')
	event.create('go_energy_red_crate').material('iron').hardness(1.0).displayName('Go Energy Tea Crate')
	event.create('go_energy_yellow_crate').material('iron').hardness(1.0).displayName('Go Energy Honey Splash Crate')
	event.create('storagium_block').material('iron').hardness(2.0).displayName('Storagium Block')
	event.create('storegalium_block').material('iron').hardness(2.0).displayName('Imporium Block')
	event.create('gotopium_block').material('iron').hardness(2.0).displayName('Gotopium Block')
	event.create('sediment_paste').material('slime').hardness(0.5).displayName('Sediment Paste')
	event.create('dedicated_storage_device').material('iron').hardness(3.0).displayName('Dedicated Storage Device')
	
	event.create('redstone_node').material('rock').hardness(3.0).displayName('Redstone Node').noDrops()
	
	event.create('cobalt_node').material('rock').hardness(3.0).displayName('Cobalt Node').noDrops()
})

onEvent('fluid.registry', event => {
	// Register new blocks here
	// event.create('example_block').material('wood').hardness(1.0).displayName('Example Block')
	event.create('go_energy_green_fluid').textureThin(0xD1A504).displayName('Go Energy Original').bucketColor(0xD1A504)
	event.create('go_energy_blue_fluid').textureThin(0x6FE3B1).displayName('Go Energy Diet').bucketColor(0x6FE3B1)
	event.create('go_energy_pink_fluid').textureThin(0x9C0225).displayName('Go Energy Mixed Berry').bucketColor(0x9C0225)
	event.create('go_energy_purple_fluid').textureThin(0xCC96FF).displayName('Go Energy Chorus Punch').bucketColor(0xCC96FF)
	event.create('go_energy_red_fluid').textureThin(0x826400).displayName('Go Energy Tea').bucketColor(0x826400)
	event.create('go_energy_yellow_fluid').textureThin(0xDBD000).displayName('Go Energy Honey Splash').bucketColor(0xDBD000)
	event.create('molten_silicon').textureThick(0xFBFFAB).displayName('Molten Silicon').bucketColor(0xFBFFAB)
	//1.2 Additions
	event.create('batter').displayName('Batter').textureStill('kubejs:block/batter_still').textureFlowing('kubejs:block/batter_flowing').bucketColor(0xF7DDC3)
	event.create('latte').displayName('Latte').textureStill('kubejs:block/latte_still').textureFlowing('kubejs:block/latte_flowing').bucketColor(0xB38657)
	event.create('mayo').displayName('Mayonnaise').textureStill('kubejs:block/mayo').textureFlowing('kubejs:block/mayo').bucketColor(0xFFF8B5)
	event.create('steamed_milk').displayName('Steamed Milk').textureStill('kubejs:block/steamed_milk').textureFlowing('kubejs:block/steamed_milk').bucketColor(0xFFFDE8)
	event.create('milk_foam').displayName('Milk Foam').textureStill('kubejs:block/milk_foam').textureFlowing('kubejs:block/milk_foam').bucketColor(0xFFFDE8)
	event.create('hot_chocolate').displayName('Hot Chocolate').textureStill('kubejs:block/hot_chocolate').textureFlowing('kubejs:block/hot_chocolate').bucketColor(0x613F00)
	event.create('cortado').displayName('Cortado').textureStill('kubejs:block/cortado').textureFlowing('kubejs:block/cortado').bucketColor(0x613F00)
	event.create('cappuccino').displayName('Cappuccino').textureStill('kubejs:block/cappuccino').textureFlowing('kubejs:block/cappuccino').bucketColor(0x613F00)
	event.create('mocha').displayName('Mocha').textureStill('kubejs:block/cappuccino').textureFlowing('kubejs:block/cappuccino').bucketColor(0x613F00)
	
	event.create('chocolate_milkshake').displayName('Chocolate Milkshake').textureStill('kubejs:block/chocolate_milkshake').textureFlowing('kubejs:block/chocolate_milkshake').bucketColor(0xB38657)
	
	event.create('caramel_milkshake').displayName('Caramel Milkshake').textureStill('kubejs:block/caramel_milkshake').textureFlowing('kubejs:block/caramel_milkshake').bucketColor(0xFFDF80)
	event.create('americano').textureThin(0x201006).displayName('Americano').bucketColor(0x201006)
	event.create('espresso').textureThin(0x171101).displayName('Espresso').bucketColor(0x171101)
	event.create('syrup').textureThin(0xFCFFE8).displayName('Syrup').bucketColor(0xFCFFE8)
	event.create('steam').textureThin(0xFCFFE8).displayName('Steam').bucketColor(0xFFFFFF)
	event.create('caramel_syrup').textureThin(0xBA7C00).displayName('Caramel Syrup').bucketColor(0xBA7C00)
	event.create('chocolate_syrup').textureThin(0x613700).displayName('Chocolate Syrup').bucketColor(0x613700)
	event.create('carbonated_water').textureThin(0x36A7f7).displayName('Carbonated Water').bucketColor(0x36A7f7)
	event.create('go_energy_fizz_fluid').textureThick(0xE8BA13).displayName('Go Energy Fizz').bucketColor(0xE8BA13)
	event.create('go_energy_fizz_raspberry_fluid').textureThick(0x79F8FC).displayName('Go Energy Fizz Blue Raspberry').bucketColor(0x79F8FC)
	event.create('go_energy_fizz_apple_fluid').textureThick(0x79FC91).displayName('Go Energy Apple and Cherry').bucketColor(0x79FC91)
	event.create('go_energy_fizz_bolloom_fluid').textureThick(0xF8BAFF).displayName('Go Energy Bolloom Blast').bucketColor(0xF8BAFF)
	event.create('go_energy_fizz_melon_fluid').textureThick(0xD2FFBA).displayName('Go Energy Melon Mix-Up').bucketColor(0xD2FFBA)
	event.create('go_energy_fizz_root_fluid').textureThick(0x9C823D).displayName('Go Energy Root Beer Kick').bucketColor(0x9C823D)
	//1.3 Additions
	event.create('enderic_acid').textureThin(0x2CCAAF).displayName('Enderic Acid').bucketColor(0x2CCAAF)
	//1.4 Additions

	event.create('molten_storagium').textureThick(0xF0A5FA).displayName('Molten Storagium').bucketColor(0xF0A5FA)
	event.create('molten_thallasium').textureThick(0x70F0E5).displayName('Molten Thallasium').bucketColor(0x70F0E5)
	event.create('molten_terminite').textureThick(0x79CED0).displayName('Molten Terminite').bucketColor(0x79CED0)
	event.create('molten_aeternium').textureThick(0x075951).displayName('Molten Aeternium').bucketColor(0x075951)
	event.create('molten_shadow_steel').textureThick(0x4C4760).displayName('Molten Shadow Steel').bucketColor(0x4C4760)
	
	event.create('molten_gotopium').textureThick(0x54F7EA).displayName('Molten Gotopium').bucketColor(0x54F7EA)
	
	event.create('lumecorn_oil').textureThin(0xCDF1DB).displayName('Lumecorn Oil').bucketColor(0xCDF1DB)
	
	
})

onEvent('item.tooltip', tooltip => {
	 tooltip.add(['kubejs:go_energy_home'], '§7The ingredients are unknown but it reminds you of home. One can will return you to the Overworld')
	 tooltip.add(['create_stuff_additions:encased_jet_chestplate'], '§4Disabled')
})

onEvent('item.registry.drillhead', event => {
    // creates a drill item with 3 durability
    event.create('gotopium_drillhead').displayName('Gotopium Drillhead').durability(1000)
})



