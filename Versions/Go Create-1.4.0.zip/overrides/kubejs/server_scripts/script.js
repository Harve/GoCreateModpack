// priority: 0
var firstPlayer = [0,0]

settings.logAddedRecipes = true
settings.logRemovedRecipes = true
settings.logSkippedRecipes = false
settings.logErroringRecipes = true

console.info('Hello, World! (You will see this line every time server resources reload)')

onEvent('recipes', event => {
	const multiSmelt = (output, input) => {
		event.smelting(output, input)
		event.blasting(output, input)
	  }
	  const multiCook = (output, input) => {
		event.smelting(output, input)
		event.smoking(output, input)
	  }
	// Change recipes here
	event.remove({mod: 'ironjetpacks'})
	event.remove({id: 'twilightforest:uncrafting_table'})
	event.remove({id: 'cc:claim_block'})
	//UNDERGARDEN CHANGES
	event.remove({id:'undergarden:catalyst'})
	event.shaped('undergarden:catalyst', [
	'GLG',
	'LRL',
	'GLG'],{
		
	G: 'minecraft:gold_ingot',
	L: 'eidolon:lead_ingot',
	R: 'minecraft:diamond'
	})
	
	//CUSTOM ORE PROCESSING
		

	  
	  
	
	console.info('Thanks for downloading Go Create!')
	
	
	//IRONCHEST CHANGES
	event.remove({id:'ironchest:chests/gold_diamond_chest'})
	event.remove({id:'ironchest:chests/silver_diamond_chest'})
	event.shaped('ironchest:diamond_chest', [
	'GDG',
	'DCD',
	'GDG'],{
	G: '#forge:glass',
	D: 'minecraft:diamond',
	C: 'ironchest:gold_chest'})
	//EIDOLON CHANGES
	event.remove({id:'eidolon:pewter_blend'})
	event.shapeless('2x eidolon:pewter_blend',['create:crushed_lead_ore','create:crushed_iron_ore'])
	
	//OTHER CHANGES
	event.remove({id:'bountifulbaubles:gloves_digging_iron'})
	event.remove({id:'bountifulbaubles:gloves_digging_diamond'})
	event.shaped('bountifulbaubles:gloves_digging_iron', [
	' LD',
	' G ',
	'I  '],{
		I: 'minecraft:iron_ingot',
	G: 'alexsmobs:falconry_glove',
	D: 'create:mechanical_drill',
	L: 'transport:iron_rail'})
	event.shaped('bountifulbaubles:gloves_digging_diamond', [
	' DD',
	' GD',
	'A  '],{
		A: 'theabyss:aberythe_gem',
	D: 'minecraft:diamond',
	G: 'bountifulbaubles:gloves_digging_iron'
	})
	event.shaped('bountifulbaubles:gloves_digging_diamond', [
	' DD',
	' GD',
	'A  '],{
		A: 'undergarden:forgotten_nugget',
	D: 'minecraft:diamond',
	G: 'bountifulbaubles:gloves_digging_iron'
	})
	//IRONJETPACKS CHANGE
	event.remove({id:'create_stuff_additions:encased_jet_recipe'})
	
	event.shaped('ironjetpacks:strap',[
	'SNS'],{
		S:'betterendforge:leather_stripe',
	N:'minecraft:iron_nugget'})
	event.shaped('ironjetpacks:copper_jetpack', [
	'SPS',
	'SJS',
	'T T'],{
		S: 'create:copper_sheet',
	P: 'ironjetpacks:copper_capacitor',
	J: 'ironjetpacks:strap',
	T: 'ironjetpacks:copper_thruster'})
	event.shaped('ironjetpacks:copper_capacitor', [
	'SZS',
	'SZS',
	'SZS'],{
		S: 'create:copper_sheet',
	
	Z: 'ironjetpacks:copper_cell'})
	event.shaped('ironjetpacks:copper_cell', [
	' T ',
	'SRS',
	' S '],{
		S: 'create:copper_sheet',
	T: 'createaddition:copper_rod',
	R: 'minecraft:redstone'})
	event.shaped('ironjetpacks:copper_thruster', [
	'SVS',
	'SPS',
	'W W'],{
		S: 'create:copper_sheet',
	V: 'create:copper_valve_handle',
	P: 'create:spout',
	W: 'createaddition:copper_wire'})
	event.recipes.create.mechanical_crafting('ironjetpacks:iron_jetpack',[
	' RCR ',
	' SPS ',
	' SJS ',
	' S S ',
	' T T '],{
		
		R:'createaddition:iron_rod',
		C:'kubejs:advanced_circuit',
		S:'create:iron_sheet',
		P:'ironjetpacks:iron_capacitor',
		J:'ironjetpacks:copper_jetpack',
		T:'ironjetpacks:iron_thruster'})
	event.shaped('ironjetpacks:iron_capacitor', [
	'TZT',
	'SZS',
	'SZS'],{
		S: 'create:iron_sheet',
	T:'createaddition:connector',
	Z: 'ironjetpacks:iron_cell'})
	event.shaped('ironjetpacks:iron_cell', [
	' W ',
	'SRS',
	' S '],{
		S: 'create:copper_sheet',
	W: 'createaddition:iron_wire',
	R: 'minecraft:redstone'})
	event.shaped('ironjetpacks:iron_thruster', [
	'SCS',
	'SZS',
	'S S'],{
		S: 'create:copper_sheet',
	Z: 'ironjetpacks:iron_cell',
	C: 'kubejs:integrated_circuit'
	})
	event.recipes.create.mechanical_crafting('ironjetpacks:gold_jetpack',[
	' RAR ',
	' PWP ',
	' SJS ',
	' S S ',
	' T T '],{
		
		R:'createaddition:gold_rod',
		A:'eidolon:gold_inlay',
		S:'create:golden_sheet',
		P:'ironjetpacks:gold_capacitor',
		W:'createaddition:gold_spool',
		J:'ironjetpacks:iron_jetpack',
		T:'ironjetpacks:gold_thruster'})
	event.shaped('ironjetpacks:gold_capacitor', [
	'TZT',
	'AZA',
	'SZS'],{
		S: 'create:golden_sheet',
	T:'minecraft:gold_ingot',
	A:'kubejs:advanced_circuit',
	Z: 'ironjetpacks:gold_cell'})
	event.shaped('ironjetpacks:gold_cell', [
	' W ',
	'SRS',
	' S '],{
		S: 'create:golden_sheet',
	W: 'createaddition:gold_wire',
	R: 'minecraft:redstone'})
	event.shaped('ironjetpacks:gold_thruster', [
	'SRS',
	'SJS',
	'S S'],{
		S: 'create:golden_sheet',
	R: 'minecraft:blaze_rod',
	J: 'twilightforest:encased_fire_jet'
	})
	event.recipes.create.mechanical_crafting('ironjetpacks:diamond_jetpack',[
	' AUA ',
	' DPD ',
	' DJD ',
	' D D ',
	' T T '],{
		
		U:'theabyss:ignisithe_gem',
		A:'theabyss:aboranys_gem',
		D:'minecraft:diamond',
		P:'ironjetpacks:diamond_capacitor',
		J:'ironjetpacks:gold_jetpack',
		T:'ironjetpacks:diamond_thruster'})
	event.recipes.create.mechanical_crafting('ironjetpacks:diamond_jetpack',[
	' AUA ',
	' DPD ',
	' DJD ',
	' D D ',
	' T T '],{
		
		U:'kubejs:storegalium_block',
		A:'kubejs:storegalium_ingot',
		D:'minecraft:diamond',
		P:'ironjetpacks:diamond_capacitor',
		J:'ironjetpacks:gold_jetpack',
		T:'ironjetpacks:diamond_thruster'})
	event.shaped('ironjetpacks:diamond_capacitor', [
	'DZD',
	'DZD',
	'DZD'],{
		D: 'minecraft:diamond',
	
	Z: 'ironjetpacks:diamond_cell'})
	event.shaped('ironjetpacks:diamond_cell', [
	' R ',
	'SDS',
	' R '],{
		S: 'minecraft:diamond',
	D: 'createaddition:diamond_grit',
	R: 'minecraft:redstone'})
	event.shaped('ironjetpacks:diamond_thruster', [
	' Z ',
	'SJS',
	'S S'],{
		S: 'minecraft:diamond',
	Z: 'ironjetpacks:diamond_cell',
	J: 'theabyss:aboranys_gem'
	})
	event.shaped('ironjetpacks:diamond_thruster', [
	' Z ',
	'SJS',
	'S S'],{
		S: 'minecraft:diamond',
	Z: 'ironjetpacks:diamond_cell',
	J: 'kubejs:storegalium_ingot'
	})
	event.recipes.create.mechanical_crafting('ironjetpacks:netherite_jetpack',[
	' SPS ',
	' SCS ',
	' SJS ',
	' S S ',
	' T T '],{
		
		C:'kubejs:microprocessor',
		S:'kubejs:netherite_sheet',
		P:'ironjetpacks:netherite_capacitor',
		J:'ironjetpacks:diamond_jetpack',
		T:'ironjetpacks:netherite_thruster'})
	event.shaped('ironjetpacks:netherite_capacitor', [
	'DZD',
	'DZD',
	'DZD'],{
		D: 'kubejs:netherite_sheet',
	
	Z: 'ironjetpacks:netherite_cell'})
	event.smithing('ironjetpacks:netherite_cell', 'ironjetpacks:diamond_cell', 'minecraft:netherite_ingot')
	event.shaped('ironjetpacks:netherite_thruster', [
	' Z ',
	'SJS',
	'S S'],{
		S: 'kubejs:netherite_sheet',
	Z: 'ironjetpacks:netherite_cell',
	J: 'betterendforge:eternal_crystal'
	})
	
	//CUSTOM FOOD 
	
	
	//BEES CHANGES
	event.remove({id:'resourcefulbees:centrifuge_controller'})
	event.remove({id:'resourcefulbees:elite_centrifuge_controller'})
	event.shaped('resourcefulbees:centrifuge_controller', [
	'CFC',
	'RAR',
	'CIC'],{
		A: 'kubejs:advanced_circuit',
		R: 'createaddition:iron_rod',
		C: 'resourcefulbees:centrifuge_casing',
		F: 'resourcefulbees:centrifuge',
	I: 'ironjetpacks:iron_capacitor'
	})
	event.shaped('resourcefulbees:elite_centrifuge_controller', [
	'CFC',
	'RAR',
	'CIC'],{
		A: 'kubejs:microprocessor',
		R: 'betterendforge:eternal_crystal',
		C: 'resourcefulbees:elite_centrifuge_casing',
		F: 'minecraft:netherite_block',
	I: 'resourcefulbees:centrifuge_controller'
	})
	
	//BUILDING GADGETS CHANGES
	event.remove({id:'buildinggadgets:gadget_building'})
	 event.shaped('buildinggadgets:gadget_building', [
	'SDS',
	'SIS',
	'SBS'],{
		I: 'kubejs:integrated_circuit',
		D: 'minecraft:dispenser',
		S: 'create:iron_sheet',
		B: 'minecraft:stone_button'
	
	})
	event.remove({id:'buildinggadgets:gadget_exchanging'})
	 event.shaped('buildinggadgets:gadget_exchanging', [
	'SDS',
	'SIS',
	'SBS'],{
		I: 'kubejs:integrated_circuit',
		D: 'minecraft:dropper',
		S: 'create:iron_sheet',
		B: 'minecraft:stone_button'
	
	})
	event.remove({id:'buildinggadgets:gadget_copy_paste'})
	 event.shaped('buildinggadgets:gadget_copy_paste', [
	'SDS',
	'EIE',
	'SBS'],{
		I: 'kubejs:integrated_circuit',
		D: 'minecraft:dropper',
		S: 'create:iron_sheet',
		E: 'minecraft:emerald',
		B: 'minecraft:stone_button'
	
	})
	event.remove({id:'buildinggadgets:gadget_destruction'})
	 event.shaped('buildinggadgets:gadget_destruction', [
	'SDS',
	'PIP',
	'SBS'],{
		I: 'kubejs:integrated_circuit',
		D: 'minecraft:dispenser',
		S: 'create:iron_sheet',
		P: 'minecraft:ender_pearl',
		B: 'minecraft:stone_button'
	
	})
	//ABYSS CHANGES
	event.shaped('theabyss:dark_stone', [
	'SSS',
	'SIS',
	'SSS'],{
		
		S: 'theabyss:cobble_stone',
		
		I: 'theabyss:fusion_ore'
	
	})
	//CHUNKLOADERS CHANGES
	event.remove({id:'chunkloaders:basic_chunk_loader'})
	 event.shaped('chunkloaders:basic_chunk_loader', [
	'SOS',
	'OIO',
	'SOS'],{
		I: 'kubejs:integrated_circuit',
		
		S: 'create:iron_sheet',
		
		O: 'minecraft:obsidian'
	
	})
	event.remove({id:'chunkloaders:advanced_chunk_loader'})
	 event.shaped('chunkloaders:advanced_chunk_loader', [
	'SBS',
	'OIO',
	'SBS'],{
		I: 'chunkloaders:basic_chunk_loader',
		
		S: 'create:golden_sheet',
		B: 'minecraft:blaze_rod',
		O: 'kubejs:advanced_circuit'
	
	})
	event.remove({id:'chunkloaders:ultimate_chunk_loader'})
	 event.shaped('chunkloaders:ultimate_chunk_loader', [
	'SOS',
	'CIC',
	'SOS'],{
		I: 'chunkloaders:advanced_chunk_loader',
		C: 'betterendforge:eternal_crystal',
		S: 'create:brass_sheet',
		
		O: 'kubejs:advanced_circuit'
	
	})
	//1.2 RECIPIES
	
	
	event.recipes.create.mixing('2x eidolon:pewter_ingot', [
	'minecraft:iron_ingot','#forge:ingots/lead']).heated()
	
	//1.3 ADDITIONS
	
	
	
	
	
	
	event.shaped('minecraft:chest',[
	'WWW',
	'W W',
	'WWW'],{
		
		W: '#minecraft:planks'
	
	})
	
 event.remove({id:'theabyss:incorythe_sword_mkii_rcp'})
 
 event.remove({id:'theabyss:knight_sword_rcp'})
 
	event.remove({id:'create:crushing/brass_block'})
	event.remove({id:'create:crushing/copper_block'})
	//Slab recipes - Credit to Lytho from the KubeJS Discord!
	 event.forEachRecipe({ type: 'minecraft:crafting_shaped', output: '#minecraft:slabs' }, r => {
    event.shaped(r.inputItems[0], ["A", "A"], { A: r.outputItems[0].withCount(1) });
  });
  
  
	event.remove({id:'witherutilsexp:xpsucker'})
	event.shaped('witherutilsexp:xpsucker',[
	'   ',
	' P ',
	' D '],{
		
		P: 'minecraft:light_weighted_pressure_plate',
		D: 'create:item_drain'
		
	
	})
	 
	
	 
	
	  
	
	  
	  var abyssTools = ['theabyss:fusion_sword','theabyss:unorithe_sword','theabyss:phantom_sword','theabyss:ignisithe_sword','theabyss:incorythe_sword','theabyss:incorythe_sword_mkii','theabyss:bricked_knight_sword','theabyss:knight_sword','theabyss:garnite_sword','theabyss:abyss_sword','theabyss:nosaj_sword','theabyss:bone_sword_item','theabyss:aberythe_sword','theabyss:aboranys_sword','theabyss:hammer_of_abyss','theabyss:fusion_pickace','theabyss:fusion_axe','theabyss:fusion_shovel','theabyss:fusion_hoe','theabyss:incorythe_pickaxe','theabyss:incorythe_axe','theabyss:incorythe_shovel','theabyss:incorythe_hoe','theabyss:phantom_pickaxe','theabyss:phantom_axe','theabyss:phantom_hoe','theabyss:phantom_shovel','theabyss:garnite_pickaxe','theabyss:garnite_axe','theabyss:garnite_hoe','theabyss:garnite_shovel','theabyss:unorithe_pick_axe','theabyss:unorithe_axe','theabyss:unorithe_hoe','theabyss:unorithe_shovel','theabyss:auto_smelt_pick_axe','theabyss:knight_pick_axe','theabyss:knight_axe','theabyss:knight_hoe','theabyss:knight_shovel','theabyss:bone_pickaxe','theabyss:bone_axe','theabyss:bone_hoe','theabyss:bone_shovel','theabyss:aberythe_pickaxe','theabyss:aberythe_axe','theabyss:aberythe_hoe','theabyss:aberythe_shovel','theabyss:aboranys_pickaxe','theabyss:aboranys_axe','theabyss:aboranys_hoe','theabyss:aboranys_shovel']
	  abyssTools.forEach((tool)=>{
		  event.remove({output: tool})
	  })
	  
	   event.shaped('theabyss:crystal_cutter',[
	' L ',
	'LSL',
	'BBB'],{
		L: 'theabyss:loran_ingot',
		S: 'minecraft:stonecutter',
		B: 'theabyss:stone_brick'
		
	
	})
	event.remove({mod:'enderstorage'})
	event.shaped('enderstorage:ender_chest',[
	'RWR',
	'SCS',
	'RTR'],{
		R: 'minecraft:blaze_rod',
		S: 'betterendforge:ender_shard',
		T: 'betterendforge:eternal_crystal',
		W: '#forge:wool',
		C: 'ironchest:obsidian_chest'
		
	
	})
	event.shaped('enderstorage:ender_tank',[
	'RWR',
	'SCS',
	'RTR'],{
		R: 'minecraft:blaze_rod',
		S: 'betterendforge:ender_shard',
		T: 'betterendforge:eternal_crystal',
		W: '#forge:wool',
		C: 'create:fluid_tank'
		
	
	})
	
	 
	 var upgradePath = ['obsidian','iron','gold','diamond','emerald']
	 for (let i = 1; i < upgradePath.length; i++) {
		  event.replaceInput({output: 'storagedrawers:'+upgradePath[i]+'_storage_upgrade'}, 'storagedrawers:upgrade_template', 'storagedrawers:'+upgradePath[i-1]+'_storage_upgrade')
		}
	  event.replaceInput({mod:'storagedrawers'}, '#forge:rods/wooden', '#forge:rods/copper')
	  
	  event.remove({id:'storagedrawers:compacting_drawers_3'})
	  event.remove({id:'storagedrawers:controller'})
	  event.remove({id:'storagedrawers:controller_slave'})
	  event.recipes.create.mechanical_crafting('storagedrawers:controller',[
	
	'SSSSS',
	'TDADT',
	'SSSSS'],{
		S:'minecraft:stone',
		T:'create:redstone_contact',
		D:'minecraft:diamond',
		A:'#storagedrawers:drawers'
	})
	event.recipes.create.mechanical_crafting('storagedrawers:controller_slave',[
	
	'SSSSS',
	'TGAGT',
	'SSSSS'],{
		S:'minecraft:stone',
		T:'create:redstone_contact',
		G:'minecraft:gold_ingot',
		A:'#storagedrawers:drawers'
	})
	event.shaped('storagedrawers:compacting_drawers_3',[
	'SSS',
	'PAP',
	'SSS'],{
		S:'minecraft:stone',
		P: 'create:mechanical_press',
		A:'#storagedrawers:drawers'
		
		
	
	})
	
	
	
	
	
	
	
	   
	   
	
	
	
	var backpackTiers = ['iron','gold','diamond','netherite']
	
	var block
	 for (let i = 0; i < upgradePath.length-1; i++){
		  event.remove({id: 'sophisticatedbackpacks:stack_upgrade_tier_'+(i+1).toString()})
		  switch(i){
			  case 0:
				  block = 'minecraft:iron_block'
				  upgrade ='sophisticatedbackpacks:upgrade_base'
				  break
			  case 1:
				  block = 'kubejs:storagium_block'
				  upgrade = 'sophisticatedbackpacks:stack_upgrade_tier_'+(i).toString()
				  break
			  case 2:
				  block = 'kubejs:storegalium_block'
				   upgrade = 'sophisticatedbackpacks:stack_upgrade_tier_'+(i).toString()
				  break
			  case 3:
				  block = 'kubejs:gotopium_block'
				   upgrade = 'sophisticatedbackpacks:stack_upgrade_tier_'+(i).toString()
				  break
		  }
			  event.recipes.create.mechanical_crafting('sophisticatedbackpacks:stack_upgrade_tier_'+(i+1).toString(),[
				'  I  ',
				' BIB ',
				'IIGII',
				' BIB ',
				'  I  '],{
				I:'minecraft:'+backpackTiers[i]+'_block',
				G: upgrade,
				B: block})
					}
		  
		  var pickingRecipes = [['createautomated:copper_ore_piece','twilightforest:torchberries'],['kubejs:storagium_nugget','undergarden:gloomgourd'],['undergarden:regalium_nugget','undergarden:glowing_kelp']]
		  pickingRecipes.forEach((pick)=>{
		  event.recipes.create.deploying(Item.of(pick[0]).withChance(0.2),[pick[1],'createautomated:picker'])
		  event.custom({
  "type": "createautomated:picking",
  "results": [
    {
      "item": pick[0],
      "chance": 0.2
    }
  ],
  "ingredient": {
    "item": pick[1]
  }
})
event.shaped('2x solarflux:sp_3', [
	'LLL',
	'PCP',
	'PSP'],{
	C: 'kubejs:integrated_circuit',
    S: 'create:iron_sheet',	
	L: 'solarflux:photovoltaic_cell_2',
	P: 'solarflux:sp_2'
	})
	event.shaped('2x solarflux:sp_4', [
	'LLL',
	'PCP',
	'PSP'],{
	C: 'kubejs:advanced_circuit',
    S: 'create:brass_sheet',	
	L: 'solarflux:photovoltaic_cell_3',
	P: 'solarflux:sp_3'
	})
	event.shaped('4x solarflux:sp_5', [
	'LLL',
	'PCP',
	'PSP'],{
	C: 'kubejs:microprocessor',
    S: 'create:brass_block',	
	L: 'solarflux:photovoltaic_cell_4',
	P: 'solarflux:sp_4'
	})
})
})



onEvent('ftbquests.completed.56394B7592CE3CDC', event => {
	event.server.runCommandSilent(`clear ${event.player} patchouli:guide_book`)
})

onEvent('ftbquests.completed.06884CCB15B9C174', event => {
	if(firstPlayer[1] == 0){
		event.server.scheduleInTicks(80, event.server, function (callback) {
		event.server.runCommand(`function structures:spread/gen_reset`)})
	firstPlayer[1] = 1}
})

onEvent('ftbquests.completed.4B22D20DD10285B4', event => {
	if(firstPlayer[1] == 0){
		event.server.scheduleInTicks(80, event.server, function (callback) {
		event.server.runCommand(`function structures:spread/gen_reset`)})
	firstPlayer[1] = 1}
})

events.listen('player.logged_in', function (event) {
	if(firstPlayer[0] == 0){
	event.server.runCommandSilent(`function structures:density/abundant`)
	event.server.runCommandSilent(`function structures:clock/normal`)
	event.server.runCommandSilent(`function generator:generate`)
	event.server.runCommandSilent(`function structures:spread/gen_reset`)
	firstPlayer[0] = 1
	}
})



