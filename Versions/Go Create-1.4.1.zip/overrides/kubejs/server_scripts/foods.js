// priority: 0

settings.logAddedRecipes = true
settings.logRemovedRecipes = true
settings.logSkippedRecipes = false
settings.logErroringRecipes = true


onEvent('recipes', event => {
	const multiSmelt = (output, input) => {
		event.smelting(output, input)
		event.blasting(output, input)
	  }
	  const multiCook = (output, input) => {
		event.smelting(output, input)
		event.smoking(output, input)
	  }
	//GO ENERGY
	event.shaped('6x kubejs:drink_can', [
	'   ',
	'I I',
	' I '],{
		
	I: 'create:iron_sheet'
	})
	
	event.shaped('kubejs:reinforced_drink_can', [
	'   ',
	'I I',
	' I '],{
		
	I: 'kubejs:storegalium_sheet'
	})
	
	event.recipes.create.sequenced_assembly([
  Item.of('kubejs:go_energy_jungle').withChance(100.0)], 'kubejs:reinforced_drink_can', [
	event.recipes.create.filling('kubejs:reinforced_drink_can', [
	  'kubejs:reinforced_drink_can',
	  Fluid.of('kubejs:go_energy_green_fluid', 100)
	]),
	event.recipes.create.filling('kubejs:reinforced_drink_can', [
	  'kubejs:reinforced_drink_can',
	  Fluid.of('kubejs:go_energy_blue_fluid', 100)
	]),
	event.recipes.create.filling('kubejs:reinforced_drink_can', [
	  'kubejs:reinforced_drink_can',
	  Fluid.of('kubejs:go_energy_pink_fluid', 100)
	]),
	event.recipes.create.filling('kubejs:reinforced_drink_can', [
	  'kubejs:reinforced_drink_can',
	  Fluid.of('kubejs:go_energy_purple_fluid', 100)
	]),
	event.recipes.create.filling('kubejs:reinforced_drink_can', [
	  'kubejs:reinforced_drink_can',
	  Fluid.of('kubejs:go_energy_red_fluid', 100)
	]),
	event.recipes.create.filling('kubejs:reinforced_drink_can', [
	  'kubejs:reinforced_drink_can',
	  Fluid.of('kubejs:go_energy_yellow_fluid', 100)
	])]).transitionalItem('kubejs:reinforced_drink_can').loops(1)
	
	
	
	event.recipes.create.filling('kubejs:go_energy_green', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_green_fluid', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_blue', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_blue_fluid', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_pink', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_pink_fluid', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_purple', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_purple_fluid', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_red', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_red_fluid', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_yellow', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_yellow_fluid', 250)
	])
	
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_green_fluid'), [
	Fluid.of('minecraft:water'),'kubejs:blazing_sugar','kubejs:flavor_blend'])
	event.shapeless('2x kubejs:flavor_blend',['simplefarming:ginger','minecraft:glowstone_dust'])
	
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_blue_fluid'),[
	Fluid.of('kubejs:go_energy_green_fluid',500),Fluid.of('theabyss:areno',500)])
	
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_purple_fluid'),[
	Fluid.of('kubejs:go_energy_green_fluid'),'minecraft:chorus_fruit'])
	
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_pink_fluid'),[
	Fluid.of('kubejs:go_energy_green_fluid'),'minecraft:sweet_berries','simplefarming:raspberries','simplefarming:strawberries'])
	
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_red_fluid'),[
	Fluid.of('kubejs:go_energy_green_fluid',500),Fluid.of('create:tea',500)])
	
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_yellow_fluid'),[
	Fluid.of('kubejs:go_energy_green_fluid',750),Fluid.of('create:honey',250)])
	
	event.recipes.create.mixing(Fluid.of('kubejs:carbonated_water',1000),[Fluid.of('minecraft:water',1000),'theabyss:thunder_nugget'])
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_fizz_fluid'), [
	Fluid.of('kubejs:carbonated_water'),'kubejs:blazing_sugar','kubejs:flavor_blend'])
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_fizz_raspberry_fluid'),[
	Fluid.of('kubejs:go_energy_fizz_fluid'),'simplefarming:raspberries','undergarden:indigo_stew'])
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_fizz_apple_fluid'),[
	Fluid.of('kubejs:go_energy_fizz_fluid'),'minecraft:apple','simplefarming:cherries'])
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_fizz_bolloom_fluid'),[
	Fluid.of('kubejs:go_energy_fizz_fluid'),'endergetic:bolloom_fruit'])
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_fizz_melon_fluid'),[
	Fluid.of('kubejs:go_energy_fizz_fluid'),'minecraft:melon_slice','simplefarming:honeydew','simplefarming:cantaloupe'])
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_fizz_root_fluid'),[
	Fluid.of('kubejs:go_energy_fizz_fluid'),'simplefarming:marshmallow_root','quark:root_item'])
	
	event.recipes.create.filling('kubejs:go_energy_fizz', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_fizz_fluid', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_fizz_apple', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_fizz_apple_fluid', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_fizz_bolloom', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_fizz_bolloom_fluid', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_fizz_melon', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_fizz_melon_fluid', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_fizz_raspberry', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_fizz_raspberry_fluid', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_fizz_root', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_fizz_root_fluid', 250)
	])
	
	//CAFE FOODS
	event.recipes.create.mixing(Fluid.of('transport:steam',1000),[Fluid.of('minecraft:water')]).heated()
	event.recipes.create.mixing(Fluid.of('kubejs:syrup',250),[Fluid.of('minecraft:water',250),'minecraft:sugar'])
	event.recipes.create.mixing(Fluid.of('kubejs:caramel_syrup',1000),[Fluid.of('kubejs:syrup',500),Item.of('kubejs:caramel',500)])
	event.recipes.create.mixing(Fluid.of('kubejs:chocolate_syrup',1000),[Fluid.of('kubejs:syrup',500),Fluid.of('create:chocolate',500)])
	event.recipes.create.mixing(Fluid.of('kubejs:hot_chocolate',1000),[Fluid.of('kubejs:steamed_milk',750),Fluid.of('create:chocolate',250)])
	event.recipes.create.mixing(Fluid.of('kubejs:steamed_milk',1000),[Fluid.of('transport:steam',250),Fluid.of('minecraft:milk',750)])
	event.recipes.create.mixing(Fluid.of('kubejs:milk_foam',1000),[Fluid.of('transport:steam',250),Fluid.of('minecraft:milk',750)]).heated()
	event.recipes.create.mixing(Fluid.of('kubejs:espresso',250),[Fluid.of('transport:steam',250),'kubejs:ground_coffee'])
	event.recipes.create.mixing(Fluid.of('kubejs:latte',500),[Fluid.of('kubejs:steamed_milk',375),Fluid.of('kubejs:espresso',125)])
	event.recipes.create.mixing(Fluid.of('kubejs:americano',500),[Fluid.of('minecraft:water',375),Fluid.of('kubejs:espresso',125)])
	event.recipes.create.mixing(Fluid.of('kubejs:cappuccino',500),[Fluid.of('kubejs:latte',375),Fluid.of('kubejs:milk_foam',125)])
	event.recipes.create.mixing(Fluid.of('kubejs:cortado',250),[Fluid.of('kubejs:espresso',125),Fluid.of('kubejs:milk_foam',125)])
	event.recipes.create.mixing(Fluid.of('kubejs:mocha',500),[Fluid.of('kubejs:cappuccino',250),Fluid.of('kubejs:hot_chocolate',250)])
	event.recipes.create.mixing(Fluid.of('kubejs:cortado',500),[Fluid.of('kubejs:espresso',125),Fluid.of('minecraft:water',375)])
	event.recipes.create.mixing(Fluid.of('kubejs:caramel_milkshake',500),['kubejs:caramel',Fluid.of('minecraft:milk',500)])
	event.recipes.create.mixing(Fluid.of('kubejs:chocolate_milkshake',500),['create:bar_of_chocolate',Fluid.of('minecraft:milk',500)])
	event.recipes.create.mixing(Fluid.of('kubejs:strawberry_milkshake',500),['simplefarming:strawberries',Fluid.of('minecraft:milk',500)])
	event.recipes.create.mixing(Fluid.of('kubejs:banana_milkshake',500),['simplefarming:banana',Fluid.of('minecraft:milk',500)])
	event.recipes.create.mixing(Fluid.of('kubejs:batter'), [
	Fluid.of('minecraft:milk'),'minecraft:egg','create:wheat_flour'])
	event.recipes.create.mixing(Fluid.of('kubejs:mayo',500), [
	Fluid.of('createaddition:seed_oil',500),'minecraft:egg','simplefarming:vinegar'])
	
	event.recipes.create.mixing('kubejs:butter', [
	Fluid.of('minecraft:milk',125),'minecraft:gold_nugget'])
	event.recipes.create.mixing('kubejs:brownie_mix', [
	'minecraft:cocoa_beans','kubejs:butter','create:wheat_flour','minecraft:egg'])
	event.recipes.create.mixing('kubejs:caramel_brownie_mix', [
	'kubejs:brownie_mix','kubejs:caramel'])
	event.recipes.create.mixing('kubejs:pastry_dough', [
	'kubejs:butter','create:dough','minecraft:sugar'])
	event.recipes.create.mixing('kubejs:oat_mix', [
	Fluid.of('kubejs:syrup',125),'simplefarming:oat'])
	event.recipes.create.mixing('kubejs:apple_fritter', [
	Fluid.of('createaddition:seed_oil',125),'kubejs:coated_apple']).heated()
	event.recipes.create.mixing('kubejs:banana_fritter', [
	Fluid.of('createaddition:seed_oil',125),'kubejs:coated_banana']).heated()
	event.recipes.create.mixing('kubejs:fried_chicken', [
	Fluid.of('createaddition:seed_oil',125),'kubejs:coated_chicken']).heated()
	event.recipes.create.mixing('2x kubejs:fries', [
	Fluid.of('createaddition:seed_oil',125),'minecraft:potato']).heated()
	event.recipes.create.mixing('kubejs:donut', [
	Fluid.of('createaddition:seed_oil',125),Fluid.of('kubejs:batter',125)]).heated()
	event.shapeless('kubejs:porcelain',['minecraft:clay_ball','minecraft:bone_meal'])
	event.shapeless('kubejs:ice_in_glass',['kubejs:tall_glass','kubejs:crushed_ice'])
	event.shapeless('kubejs:fries_with_mayo',['kubejs:fries','kubejs:bottle_of_mayo'])
	event.shapeless('3x kubejs:empty_espresso_cup',['kubejs:porcelain'])
	event.shapeless('12x kubejs:ginger_biscuit',['simplefarming:ginger','kubejs:butter','create:wheat_flour','minecraft:sugar'])
	event.shapeless('8x kubejs:jam_slice',['simplefarming:jam','kubejs:butter','create:wheat_flour','minecraft:sugar'])
	event.shapeless('8x kubejs:rocky_road',['minecraft:cocoa_beans','kubejs:butter','create:wheat_flour','simplefarming:marshmallow'])
	event.shapeless('kubejs:potato_salad',['minecraft:potato','simplefarming:onion','kubejs:bottle_of_mayo','minecraft:bowl'])
	event.shapeless('kubejs:coronation_chicken',['simplefarming:curry_powder','minecraft:cooked_chicken','kubejs:bottle_of_mayo','minecraft:bread'])
	event.shapeless('kubejs:pasta_salad',['simplefarming:pasta','kubejs:bottle_of_mayo','simplefarming:tomato','simplefarming:corn'])
	event.recipes.create.milling(
	  'kubejs:ground_coffee',
	  'undergarden:roasted_underbeans')
	  event.recipes.create.milling(
	  '2x kubejs:crushed_ice',
	  'minecraft:ice')
	event.recipes.create.compacting('2x kubejs:croissant_pastry',['kubejs:pastry_dough'])
	event.recipes.create.compacting('4x kubejs:flapjack',['kubejs:oat_mix'])
	event.shaped('3x kubejs:empty_cup', [
	'   ',
	'P P',
	' P '],{
		
	
	P: 'kubejs:porcelain'
	})
	event.shaped('3x kubejs:tall_glass', [
	'   ',
	'P P',
	' P '],{
		
	
	P: 'minecraft:glass_pane'
	})
	event.shaped('kubejs:millionaire_shortbread', [
	'C',
	'A',
	'S'],{
	C: 'create:bar_of_chocolate',	
	A: 'kubejs:caramel',
	S: 'kubejs:shortbread'
	})
	
	event.shaped('solarflux:photovoltaic_cell_4', [
	'LLL',
	'PCP',
	'ISI'],{
	C: 'betterendforge:eternal_crystal',
	 I: 'kubejs:integrated_circuit',	
    S: 'solarflux:photovoltaic_cell_3',	
	L: 'minecraft:blaze_powder',
	P: 'minecraft:glowstone_dust'
	})
	event.shaped('kubejs:go_energy_crate', [
	'CCC',
	'CCC',
	'CCC'],{
	C: 'kubejs:go_energy_green'
	})
	event.shaped('kubejs:go_energy_blue_crate', [
	'CCC',
	'CCC',
	'CCC'],{
	C: 'kubejs:go_energy_blue'
	})
	event.shaped('kubejs:go_energy_pink_crate', [
	'CCC',
	'CCC',
	'CCC'],{
	C: 'kubejs:go_energy_pink'
	})
	event.shaped('kubejs:go_energy_red_crate', [
	'CCC',
	'CCC',
	'CCC'],{
	C: 'kubejs:go_energy_red'
	})
	event.shaped('kubejs:go_energy_purple_crate', [
	'CCC',
	'CCC',
	'CCC'],{
	C: 'kubejs:go_energy_purple'
	})
	event.shaped('kubejs:go_energy_yellow_crate', [
	'CCC',
	'CCC',
	'CCC'],{
	C: 'kubejs:go_energy_yellow'
	})
	event.recipes.create.filling('kubejs:hot_chocolate', [
	  'kubejs:empty_cup',
	  Fluid.of('kubejs:hot_chocolate', 250)
	])
	event.recipes.create.filling('kubejs:cappuccino', [
	  'kubejs:empty_cup',
	  Fluid.of('kubejs:cappuccino', 250)
	])
	event.recipes.create.filling('kubejs:mocha', [
	  'kubejs:empty_cup',
	  Fluid.of('kubejs:mocha', 250)
	])
	event.recipes.create.filling('kubejs:americano', [
	  'kubejs:empty_cup',
	  Fluid.of('kubejs:americano', 250)
	])
	event.recipes.create.filling('kubejs:espresso', [
	  'kubejs:empty_espresso_cup',
	  Fluid.of('kubejs:espresso', 125)
	])
	event.recipes.create.filling('kubejs:cortado', [
	  'kubejs:empty_espresso_cup',
	  Fluid.of('kubejs:cortado', 125)
	])
	event.recipes.create.filling('kubejs:latte', [
	  'kubejs:tall_glass',
	  Fluid.of('kubejs:latte', 250)
	])
	event.recipes.create.filling('kubejs:banana_milkshake', [
	  'kubejs:tall_glass',
	  Fluid.of('kubejs:banana_milkshake', 250)
	])
	event.recipes.create.filling('kubejs:strawberry_milkshake', [
	  'kubejs:tall_glass',
	  Fluid.of('kubejs:strawberry_milkshake', 250)
	])
	event.recipes.create.filling('kubejs:caramel_milkshake', [
	  'kubejs:tall_glass',
	  Fluid.of('kubejs:caramel_milkshake', 250)
	])
	event.recipes.create.filling('kubejs:chocolate_milkshake', [
	  'kubejs:tall_glass',
	  Fluid.of('kubejs:chocolate_milkshake', 250)
	])
	event.recipes.create.filling('kubejs:iced_latte', [
	  'kubejs:ice_in_glass',
	  Fluid.of('kubejs:latte', 250)
	])
	event.recipes.create.filling('kubejs:iced_coffee', [
	  'kubejs:ice_in_glass',
	  Fluid.of('kubejs:americano', 250)
	])
	
	event.recipes.create.filling('kubejs:coated_apple', [
	  'minecraft:apple',
	  Fluid.of('kubejs:batter', 125)
	])
	event.recipes.create.filling('kubejs:coated_banana', [
	  'simplefarming:banana',
	  Fluid.of('kubejs:batter', 125)
	])
	event.recipes.create.filling('kubejs:coated_chicken', [
	  'minecraft:chicken',
	  Fluid.of('kubejs:batter', 125)
	])
	event.recipes.create.filling('kubejs:bottle_of_mayo', [
	  'minecraft:glass_bottle',
	  Fluid.of('kubejs:mayo', 250)
	])
	event.recipes.create.filling('kubejs:cappuccino_caramel', [
	  'kubejs:cappuccino',
	  Fluid.of('kubejs:caramel_syrup', 125)
	])
	event.recipes.create.filling('kubejs:latte_caramel', [
	  'kubejs:latte',
	  Fluid.of('kubejs:caramel_syrup', 125)
	])
	event.recipes.create.filling('kubejs:iced_latte_caramel', [
	  'kubejs:iced_latte',
	  Fluid.of('kubejs:caramel_syrup', 125)
	])
	event.recipes.create.filling('kubejs:cappuccino_chocolate', [
	  'kubejs:cappuccino',
	  Fluid.of('kubejs:chocolate_syrup', 125)
	])
	event.recipes.create.filling('kubejs:latte_chocolate', [
	  'kubejs:latte',
	  Fluid.of('kubejs:chocolate_syrup', 125)
	])
	event.recipes.create.filling('kubejs:iced_latte_chocolate', [
	  'kubejs:iced_latte',
	  Fluid.of('kubejs:chocolate_syrup', 125)
	])
	multiCook('kubejs:shortbread','kubejs:pastry_dough')
	multiCook('kubejs:croissant','kubejs:croissant_pastry')
	multiCook('kubejs:caramel','minecraft:sugar')
	multiCook('kubejs:brownie','kubejs:brownie_mix')
	multiCook('kubejs:caramel_brownie','kubejs:caramel_brownie_mix')
})






