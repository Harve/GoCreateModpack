// priority: 0

console.info('Hello, World! (You will see this line every time client resources reload)')

onEvent('jei.hide.items', event => {
	 
 
  event.hide('createaddition:furnace_burner')
  event.hide('refinedstorage:basic_processor')
  event.hide('refinedstorage:improved_processor')
  event.hide('refinedstorage:advanced_processor')
  event.hide('refinedstorage:raw_basic_processor')
  event.hide('refinedstorage:raw_improved_processor')
  event.hide('refinedstorage:raw_advanced_processor')
  event.hide('refinedstorage:improved_processor')
  event.hide('twilightforest:uncrafting_table')
  event.hide('twilightforest:twilight_oak_door')
  event.hide('twilightforest:canopy_door')
  event.hide('twilightforest:mangrove_door')
  event.hide('twilightforest:dark_door')
  event.hide('twilightforest:time_door')
  event.hide('twilightforest:trans_trapdoor')
  event.hide('twilightforest:trans_door')
  event.hide('twilightforest:mine_door')
  event.hide('twilightforest:sort_door')
  event.hide('tconstruct:blank_cast')
  event.hide('tconstruct:ingot_cast')
  event.hide('tconstruct:nugget_cast')
  event.hide('tconstruct:gem_cast')
  event.hide('tconstruct:rod_cast')
  event.hide('tconstruct:repair_kit_cast')
  event.hide('tconstruct:plate_cast')
  event.hide('tconstruct:pickaxe_head_cast')
  event.hide('tconstruct:small_axe_head_cast')
  event.hide('tconstruct:small_blade_cast')
  event.hide('tconstruct:hammer_head_cast')
  event.hide('tconstruct:broad_blade_cast')
  event.hide('tconstruct:broad_axe_head_cast')
  event.hide('tconstruct:tool_binding_cast')
  event.hide('tconstruct:large_plate_cast')
  event.hide('tconstruct:tool_handle_cast')
  event.hide('tconstruct:tough_tool_handle_cast')
   event.hide('tconstruct:tough_handle_cast')
  event.hide('extradisks:infinite_storage_block')
  event.hide('extradisks:infinite_storage_part')
  event.hide('extradisks:infinite_storage_disk')
  event.hide('extradisks:infinite_fluid_storage_block')
  event.hide('extradisks:infinite_fluid_storage_part')
  event.hide('extradisks:infinite_storage_disk')
  event.hide('enderstorage:ender_pouch')
  event.hide('refinedstorage:quartz_enriched_iron_block')
	event.hide('tconstruct:copper_ore')
	event.hide('createdeco:zinc_sheet')
  

  
 
  event.hide('betterendforge:pearlberry_seed')
  	  var abyssTools = ['create_stuff_additions:encased_jet_chestplate','theabyss:fusion_sword','theabyss:unorithe_sword','theabyss:nosaj_sword','theabyss:phantom_sword','theabyss:ignisithe_sword','theabyss:incorythe_sword','theabyss:incorythe_sword_mkii','theabyss:bricked_knight_sword','theabyss:knight_sword','theabyss:garnite_sword','theabyss:abyss_sword','theabyss:nosaj_sword','theabyss:bone_sword_item','theabyss:aberythe_sword','theabyss:aboranys_sword','theabyss:hammer_of_abyss','theabyss:fusion_pickaxe','theabyss:fusion_axe','theabyss:fusion_shovel','theabyss:fusion_hoe','theabyss:incorythe_pickaxe','theabyss:incorythe_axe','theabyss:incorythe_shovel','theabyss:incorythe_hoe','theabyss:phantom_pickaxe','theabyss:phantom_axe','theabyss:phantom_hoe','theabyss:phantom_shovel','theabyss:garnite_pickaxe','theabyss:garnite_axe','theabyss:garnite_hoe','theabyss:garnite_shovel','theabyss:unorithe_pick_axe','theabyss:unorithe_axe','theabyss:unorithe_hoe','theabyss:unorithe_shovel','theabyss:auto_smelt_pick_axe','theabyss:knight_pick_axe','theabyss:knight_axe','theabyss:knight_hoe','theabyss:knight_shovel','theabyss:bone_pickaxe','theabyss:bone_axe','theabyss:bone_hoe','theabyss:bone_shovel','theabyss:aberythe_pickaxe','theabyss:aberythe_axe','theabyss:aberythe_hoe','theabyss:aberythe_shovel','theabyss:aboranys_pickaxe','theabyss:aboranys_axe','theabyss:aboranys_hoe','theabyss:aboranys_shovel']
	  abyssTools.forEach((tool)=>{
		  event.hide(Item.of(tool).ignoreNBT())
	  })
 
   })
