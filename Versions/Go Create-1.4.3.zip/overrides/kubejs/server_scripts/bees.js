// priority: 0

settings.logAddedRecipes = true
settings.logRemovedRecipes = true
settings.logSkippedRecipes = false
settings.logErroringRecipes = true


onEvent('recipes', event => {
	 event.shaped('9x minecraft:red_dye', [
	'   ',
	'EEE',
	'   '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	 event.shaped('9x minecraft:pink_dye', [
	'E  ',
	' E ',
	'  E'],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:purple_dye', [
	'  E',
	'  E',
	'  E'],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:yellow_dye', [
	'E E',
	' E ',
	'   '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:orange_dye', [
	'   ',
	'E E',
	' E '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:cyan_dye', [
	' E ',
	'E  ',
	'E  '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:light_blue_dye', [
	' E ',
	'E E',
	'   '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:light_gray_dye', [
	'   ',
	' EE',
	'E  '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:magenta_dye', [
	'E  ',
	' E ',
	'E  '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:lime_dye', [
	'  E',
	' E ',
	'E  '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:gray_dye', [
	' E ',
	'E  ',
	' E '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:blue_dye', [
	'  E',
	'  E',
	' E '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:green_dye', [
	'E  ',
	'E  ',
	' E '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:brown_dye', [
	'E  ',
	' EE',
	'   '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:white_dye', [
	'E  ',
	'EE ',
	'   '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:black_dye', [
	'   ',
	' EE',
	'  E'],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
})






