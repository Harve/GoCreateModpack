// priority: 0

settings.logAddedRecipes = true
settings.logRemovedRecipes = true
settings.logSkippedRecipes = false
settings.logErroringRecipes = true


onEvent('item.tags', event => {
  event.add('forge:workbench', 'minecraft:crafting_table')
  event.add('forge:ores','kubejs:storagium_ore')
  event.add('forge:ores/storagium','kubejs:storagium_ore')
  event.add('forge:ores','kubejs:stone_storagium_ore')
  event.add('forge:ores/storagium','kubejs:stone_storagium_ore')
  event.add('forge:nuggets','kubejs:storagium_nugget')
  event.add('forge:nuggets/storagium','kubejs:storagium_nugget')
  event.add('forge:ingots','kubejs:storagium_ingot')
  event.add('forge:ingots/storagium','kubejs:storagium_ingot')
  event.add('forge:storage_blocks','kubejs:storagium_block')
  event.add('forge:storage_blocks/storagium','kubejs:storagium_block')
  
  
  event.add('forge:nuggets','kubejs:storegalium_nugget')
  event.add('forge:nuggets/storegalium','kubejs:storegalium_nugget')
  event.add('forge:ingots','kubejs:storegalium_ingot')
  event.add('forge:ingots/storegalium','kubejs:storegalium_ingot')
  event.add('forge:storage_blocks','kubejs:storegalium_block')
  event.add('forge:storage_blocks/storegalium','kubejs:storegalium_block')
  event.add('forge:plates','kubejs:storegalium_sheet')
  event.add('forge:plates/storegalium','kubejs:storegalium_sheet')
  
  event.add('forge:ores','kubejs:gotopium_ore')
  event.add('forge:ores/gotopium','kubejs:gotopium_ore')
  event.add('forge:nuggets','kubejs:gotopium_nugget')
  event.add('forge:nuggets/gotopium','kubejs:gotopium_nugget')
  event.add('forge:ingots','kubejs:gotopium_ingot')
  event.add('forge:ingots/gotopium','kubejs:gotopium_ingot')
  event.add('forge:storage_blocks','kubejs:gotopium_block')
  event.add('forge:storage_blocks/gotopium','kubejs:gotopium_block')
  event.add('forge:plates','kubejs:gotopium_sheet')
  event.add('forge:plates/gotopium','kubejs:gotopium_sheet')
   event.add('forge:nuggets','eidolon:lead_nugget')
  
  
  event.add('create:crushed_ores','kubejs:crushed_storagium_ore')
  event.add('create:crushed_ores','kubejs:crushed_cloggrum_ore')
  event.add('create:crushed_ores','kubejs:crushed_cobalt_ore')
  event.add('create:crushed_ores','kubejs:crushed_froststeel_ore')
  event.add('create:crushed_ores','kubejs:crushed_regalium_ore')
  event.add('create:crushed_ores','kubejs:crushed_thallasium_ore')
  event.add('create:crushed_ores','kubejs:crushed_utherium_ore')
  event.add('create:crushed_ores','kubejs:crushed_storegalium')
  event.add('create:crushed_ores','kubejs:crushed_gotopium_ore')
  
   event.add('create:crushed_ores/storagium','kubejs:crushed_storagium_ore')
  event.add('create:crushed_ores/cloggrum','kubejs:crushed_cloggrum_ore')
  event.add('create:crushed_ores/cobalt','kubejs:crushed_cobalt_ore')
  event.add('create:crushed_ores/froststeel','kubejs:crushed_froststeel_ore')
  event.add('create:crushed_ores/regalium','kubejs:crushed_regalium_ore')
  event.add('create:crushed_ores/thallasium','kubejs:crushed_thallasium_ore')
  event.add('create:crushed_ores/utherium','kubejs:crushed_utherium_ore')
    event.add('create:crushed_ores/storegalium','kubejs:crushed_storegalium')
  event.add('create:crushed_ores/gotopium','kubejs:crushed_gotopium_ore')
  
  event.add('kubejs:impure_dust','kubejs:impure_iron_dust')
  event.add('kubejs:impure_dust','kubejs:impure_gold_dust')
  event.add('kubejs:impure_dust','kubejs:impure_copper_dust')
  event.add('kubejs:impure_dust','kubejs:impure_lead_dust')
  event.add('kubejs:impure_dust','kubejs:impure_storagium_dust')
  event.add('kubejs:impure_dust','kubejs:impure_zinc_dust')
  event.add('kubejs:shadowtools','create_stuff_additions:shadow_steel_axe')
  event.add('kubejs:shadowtools','create_stuff_additions:shadow_steel_pickaxe')
  event.add('kubejs:shadowtools','create_stuff_additions:shadow_steel_shovel')
  event.add('kubejs:shadowtools','create_stuff_additions:shadow_steel_sword')
  event.add('kubejs:blazingtools','create_stuff_additions:blazing_cleaver')
  event.add('kubejs:blazingtools','create_stuff_additions:blazing_pickaxe')
  event.add('kubejs:blazingtools','create_stuff_additions:blazing_shovel')

 event.add('kubejs:impure_dust','kubejs:impure_cloggrum_dust')
  event.add('kubejs:impure_dust','kubejs:impure_cobalt_dust')
  event.add('kubejs:impure_dust','kubejs:impure_froststeel_dust')
  event.add('kubejs:impure_dust','kubejs:impure_regalium_dust')
  event.add('kubejs:impure_dust','kubejs:impure_utherium_dust')
  event.add('kubejs:impure_dust','kubejs:impure_thallasium_dust')
   event.add('kubejs:impure_dust','kubejs:impure_storegalium_dust')
  event.add('kubejs:impure_dust','kubejs:impure_gotopium_dust')
  
  var abyssMats = ['blaru','jungle','ruma','roggen','tantra','bog','sal','slimed','frozen','cobble_stone','stone_brick','frost_bricks']
  abyssMats.forEach((mat) => {
	   event.add('minecraft:slabs','theabyss:'+mat+'_slab')
	   console.info('GO CREATE')
  })
  event.add('forge:ores','theabyss:gold_variant')
  event.add('forge:ores/gold','theabyss:gold_variant')

  event.add('forge:ores','theabyss:diamond_variant')
  event.add('forge:ores/diamond','theabyss:diamond_variant')

  event.add('forge:ores','theabyss:iron_variant')
  event.add('forge:ores/iron','theabyss:iron_variant')

  event.add('forge:ores','theabyss:emerald_variant')
  event.add('forge:ores/emerald','theabyss:emerald_variant')

  event.add('forge:ores','theabyss:fusion_ore')

  event.add('forge:ores','theabyss:loran_ore')

  event.add('forge:ores','theabyss:garnite_ore')
  event.add('forge:ores/garnite','theabyss:garnite_ore')

  event.add('forge:ores','theabyss:ignisithe_ore')

  event.add('forge:ores','theabyss:aboranys_ore')

  event.add('forge:ores','theabyss:glacerythe_ore')

  event.add('forge:ores','theabyss:aberythe_ore')

  event.add('forge:ores','theabyss:incorythe_ore')
 
  event.add('forge:ingots','theabyss:fusion_ingot')
  event.add('forge:ingots/fusion','theabyss:fusion_ingot')
  
  event.add('forge:ingots','theabyss:loran_ingot')
  event.add('forge:ingots/loran','theabyss:loran_ingot')
  
  event.add('forge:ingots','theabyss:unorithe_ingot')
  event.add('forge:ingots/unorithe','theabyss:unorithe_ingot')
  
  event.add('forge:ingots','theabyss:knight_ingot')
  event.add('forge:ingots/knight','theabyss:knight_ingot')
  
  event.add('forge:ingots','theabyss:phantom_ingot')
  event.add('forge:ingots/phantom','theabyss:phantom_ingot')
  
  event.add('forge:ingots','theabyss:garnite_ingot')
  event.add('forge:ingots/garnite','theabyss:garnite_ingot')
  
  event.add('forge:ingots/refined_radiance','create:refined_radiance')
  event.add('forge:ingots/shadow_steel','create:shadow_steel')
  
  event.add('forge:storage_blocks/thallasium','betterendforge:thallasium_block')
  event.add('forge:storage_blocks/terminite','betterendforge:terminite_block')
  event.add('forge:storage_blocks/aeternium','betterendforge:aeternium_block')
  
  event.add('supplementaries:shulker_blacklist','sophisticatedbackpacks:backpack')
  
  var drinkItems= ['kubejs:drink_can','kubejs:reinforced_drink_can','kubejs:go_energy_green','kubejs:go_energy_blue','kubejs:go_energy_pink','kubejs:go_energy_purple','kubejs:go_energy_red','kubejs:go_energy_jungle','kubejs:go_energy_yellow','kubejs:bottle_of_mayo','kubejs:tall_glass','kubejs:empty_cup','kubejs:hot_chocolate','kubejs:cappuccino','kubejs:mocha','kubejs:americano','kubejs:espresso','kubejs:cortado',
'kubejs:latte','kubejs:banana_milkshake','kubejs:strawberry_milkshake','kubejs:caramel_milkshake','kubejs:chocolate_milkshake','kubejs:ice_in_glass','kubejs:iced_latte','kubejs:iced_coffee','kubejs:cappuccino_caramel','kubejs:latte_caramel','kubejs:iced_latte_caramel','kubejs:cappuccino_chocolate','kubejs:latte_chocolate','kubejs:iced_latte_chocolate','kubejs:go_energy_fizz','kubejs:go_energy_fizz_apple','kubejs:go_energy_fizz_bolloom','kubejs:go_energy_fizz_melon','kubejs:go_energy_fizz_raspberry','kubejs:go_energy_fizz_root']
drinkItems.forEach((drink)=>{
	event.add('create:upright_on_belt',drink)
})

 event.add('tconstruct:casts','kubejs:drill_sand_cast')
  event.add('tconstruct:casts/sand','kubejs:drill_sand_cast')
  event.add('tconstruct:casts/single_use','kubejs:drill_sand_cast')
  event.add('tconstruct:casts/drill_head','kubejs:drill_sand_cast')
  event.add('tconstruct:casts','kubejs:drill_red_sand_cast')
  event.add('tconstruct:casts/red_sand','kubejs:drill_red_sand_cast')
  event.add('tconstruct:casts/single_use','kubejs:drill_red_sand_cast')
  event.add('tconstruct:casts/drill_head','kubejs:drill_red_sand_cast')
  
  event.add('createautomated:ore_pieces','kubejs:storagium_ore_piece')
  event.add('createautomated:ore_pieces','kubejs:cobalt_ore_piece')
  event.add('createautomated:ore_pieces','kubejs:regalium_ore_piece')
  event.add('createautomated:ore_pieces/storagium','kubejs:storagium_ore_piece')
  event.add('createautomated:ore_pieces/cobalt','kubejs:cobalt_ore_piece')
  event.add('createautomated:ore_pieces/regalium','kubejs:regalium_ore_piece')
})





