// priority: 0
onEvent('worldgen.add', event => {
	event.addOre(ore => {
    ore.block = 'kubejs:storagium_node' // Block ID (Use [] syntax for properties)
    ore.spawnsIn.blacklist = false // Inverts spawn whitelist
    ore.spawnsIn.values = [ // List of valid block IDs or tags that the ore can spawn in
      'undergarden:sediment' // Default behavior - ores spawn in all stone types
    ]
    
    ore.biomes.blacklist = true // Inverts biome whitelist
    ore.biomes.values = [ 
	'#nether'
    ]
    
    ore.clusterMinSize = 3 // Min blocks per cluster (currently ignored, will be implemented later, it's always 1)
    ore.clusterMaxSize = 6 // Max blocks per cluster
    ore.clusterCount = 4 // Clusters per chunk
    ore.minHeight = 0 // Min Y ore spawns in
    ore.maxHeight = 64 // Max Y ore spawns in
    ore.squared = true // Adds random value to X and Z between 0 and 16. Recommended to be true
    //ore.chance = 3 // Spawns the ore every ~4 chunks. You usually combine this with clusterCount = 1 for rare ores
  })
	event.addOre(ore => {
    ore.block = 'kubejs:regalium_node' // Block ID (Use [] syntax for properties)
    ore.spawnsIn.blacklist = false // Inverts spawn whitelist
    ore.spawnsIn.values = [ // List of valid block IDs or tags that the ore can spawn in
      'undergarden:sediment' // Default behavior - ores spawn in all stone types
    ]
    
    ore.biomes.blacklist = true // Inverts biome whitelist
    ore.biomes.values = [ 
	'#nether'
    ]
    
    ore.clusterMinSize = 3 // Min blocks per cluster (currently ignored, will be implemented later, it's always 1)
    ore.clusterMaxSize = 6 // Max blocks per cluster
    ore.clusterCount = 2 // Clusters per chunk
    ore.minHeight = 0 // Min Y ore spawns in
    ore.maxHeight = 64 // Max Y ore spawns in
    ore.squared = true // Adds random value to X and Z between 0 and 16. Recommended to be true
    //ore.chance = 3 // Spawns the ore every ~4 chunks. You usually combine this with clusterCount = 1 for rare ores
  })
  
  event.addOre(ore => {
    ore.block = 'kubejs:redstone_node' // Block ID (Use [] syntax for properties)
    ore.spawnsIn.blacklist = false // Inverts spawn whitelist
    ore.spawnsIn.values = [ // List of valid block IDs or tags that the ore can spawn in
      'minecraft:grass_block' // Default behavior - ores spawn in all stone types
    ]
    
    ore.biomes.blacklist = false // Inverts biome whitelist
    ore.biomes.values = [ 
	'#savanna'
    ]
    
    ore.clusterMinSize = 1 // Min blocks per cluster (currently ignored, will be implemented later, it's always 1)
    ore.clusterMaxSize = 2 // Max blocks per cluster
    ore.clusterCount = 1 // Clusters per chunk
    ore.minHeight = 50 // Min Y ore spawns in
    ore.maxHeight = 128 // Max Y ore spawns in
    ore.squared = true // Adds random value to X and Z between 0 and 16. Recommended to be true
    //ore.chance = 1 // Spawns the ore every ~4 chunks. You usually combine this with clusterCount = 1 for rare ores
	ore.worldgenLayer = 'top_layer_modification'
  })
  
  event.addOre(ore => {
    ore.block = 'kubejs:cobalt_node' // Block ID (Use [] syntax for properties)
    ore.spawnsIn.blacklist = false // Inverts spawn whitelist
    ore.spawnsIn.values = [ // List of valid block IDs or tags that the ore can spawn in
      'minecraft:soul_sand' // Default behavior - ores spawn in all stone types
    ]
    
    ore.biomes.blacklist = false // Inverts biome whitelist
    ore.biomes.values = [ 
	'minecraft:soul_sand_valley'
    ]
    
    ore.clusterMinSize = 1 // Min blocks per cluster (currently ignored, will be implemented later, it's always 1)
    ore.clusterMaxSize = 2 // Max blocks per cluster
    ore.clusterCount = 3 // Clusters per chunk
    ore.minHeight = 0 // Min Y ore spawns in
    ore.maxHeight = 128 // Max Y ore spawns in
    ore.squared = true // Adds random value to X and Z between 0 and 16. Recommended to be true
    //ore.chance = 4 // Spawns the ore every ~4 chunks. You usually combine this with clusterCount = 1 for rare ores
  })
})