// priority: 0

settings.logAddedRecipes = true
settings.logRemovedRecipes = true
settings.logSkippedRecipes = false
settings.logErroringRecipes = true


onEvent('recipes', event => {
	 //==Tinkers Construct Scripts==
	 //==Credit to Monkeygogobeans for their CraftTweaker script!==
	 //In order to avoid infite materials, set the melting value off all tool parts to 125mb
	 //2D Array of the type of tool and show much fluid it requires in mB
	 var castTypes = [['tool_handle',144],['tough_handle',432],['tool_binding',144],['pickaxe_head',288],['repair_kit',288],['small_axe_head',288],['small_blade',288],['hammer_head',1000],['broad_blade',1000],['broad_axe_head',1000],['large_plate',576]]
	 //Array of metals present by default in TiC
	 var tinkersMetals = ['iron','copper','tinkers_bronze','slimesteel','pig_iron','rose_gold','cobalt','queens_slime','hepatizon','manyullyn','lead']
	 //Array of metals added by KubeJS (Molten fluid added by KubeJS, everything else done via datapack)
	 var customMetals = ['cloggrum','forgotten','froststeel','knightmetal','regalium','storagium','utherium','arcane_gold','fiery','fusion','knight','phantom','unorithe','thallasium','terminite','aeternium','shadow_steel','garnite','gotopium','horizonite']
	 //Array of non-metals
	 var tinkersNonMetals = ['wood','stone','flint','bone','necrotic_bone','ironwood']
	 //Array of materials that require a tool part to be filled with fluid ( [RESULTING MATERIAL, STARTING MATERIAL, FLUID] )
	 var alternateMaterials = [['blazing_bone','necrotic_bone','blazing_blood'],['bloodbone','bone','blood'],['nahuatl','wood','molten_obsidian'],['slimewood','wood','earth_slime']]
	 
	 
	 castTypes.forEach((cast)=>{
		 //Removes existing recipes
		 event.remove({id: 'tconstruct:smeltery/casts/sand_casts/'+cast[0]})
		 event.remove({id: 'tconstruct:smeltery/casts/red_sand_casts/'+cast[0]})
		 event.remove({id: 'tconstruct:smeltery/casts/gold_casts/'+cast[0]})
		 event.remove({input: 'tconstruct:' +cast[0]+'_sand_cast'})
		 event.remove({input: 'tconstruct:' +cast[0]+'_red_sand_cast'})
		 event.remove({input: 'tconstruct:' +cast[0]+'_cast'})
		 
		 //Loop for default metals
		 tinkersMetals.forEach((metal) => {
				event.recipes.create.compacting(['tconstruct:'+cast[0]+'_sand_cast',Item.of('tconstruct:'+cast[0], {Material:"tconstruct:"+metal})],[Item.of('tconstruct:'+cast[0], {Material:"tconstruct:"+metal}),'tconstruct:blank_sand_cast'])
				event.recipes.create.compacting(['tconstruct:'+cast[0]+'_red_sand_cast',Item.of('tconstruct:'+cast[0], {Material:"tconstruct:"+metal})] ,[Item.of('tconstruct:'+cast[0], {Material:"tconstruct:"+metal}),'tconstruct:blank_red_sand_cast'])
				event.recipes.create.filling(Item.of('tconstruct:'+cast[0], {Material:"tconstruct:"+metal}) , ['tconstruct:'+cast[0]+'_sand_cast',Fluid.of('tconstruct:molten_'+metal, cast[1])])
				event.recipes.create.filling(Item.of('tconstruct:'+cast[0], {Material:"tconstruct:"+metal}) , ['tconstruct:'+cast[0]+'_red_sand_cast',Fluid.of('tconstruct:molten_'+metal, cast[1])])
		})
		//Loop for custom metals
		customMetals.forEach((metal) => {
			
			event.recipes.create.compacting(['tconstruct:'+cast[0]+'_sand_cast',Item.of('tconstruct:'+cast[0], {Material:"tconstruct:"+metal})],[Item.of('tconstruct:'+cast[0], {Material:"tconstruct:"+metal}),'tconstruct:blank_sand_cast'])
			event.recipes.create.compacting(['tconstruct:'+cast[0]+'_red_sand_cast',Item.of('tconstruct:'+cast[0], {Material:"tconstruct:"+metal})] ,[Item.of('tconstruct:'+cast[0], {Material:"tconstruct:"+metal}),'tconstruct:blank_red_sand_cast'])
			event.recipes.create.filling(Item.of('tconstruct:'+cast[0], {Material:"tconstruct:"+metal}) , [ 'tconstruct:'+cast[0]+'_sand_cast',Fluid.of('kubejs:molten_'+metal, cast[1])])
			event.recipes.create.filling(Item.of('tconstruct:'+cast[0], {Material:"tconstruct:"+metal}) , ['tconstruct:'+cast[0]+'_red_sand_cast',Fluid.of('kubejs:molten_'+metal, cast[1])])
		})
		//Loop for non metals
		tinkersNonMetals.forEach((nonMetal) => {
			event.recipes.create.compacting('tconstruct:'+cast[0]+'_sand_cast',[Item.of('tconstruct:'+cast[0], {Material:"tconstruct:"+nonMetal}),'tconstruct:blank_sand_cast'])
			event.recipes.create.compacting('tconstruct:'+cast[0]+'_red_sand_cast' ,[Item.of('tconstruct:'+cast[0], {Material:"tconstruct:"+nonMetal}),'tconstruct:blank_red_sand_cast'])
	    })
		//Loop for alternate materials
		 alternateMaterials.forEach((material) =>{
			  
			 event.recipes.create.filling(Item.of('tconstruct:'+cast[0], {Material:"tconstruct:"+material[0]}) , [Item.of('tconstruct:'+cast[0], {Material:"tconstruct:"+material[1]}),Fluid.of('tconstruct:'+material[2], cast[1])])
		 })
		 
	 })
	 
	 event.remove({output:'tconstruct:grout'})
	 event.shapeless('8x tconstruct:grout',['kubejs:sediment_paste','4x #forge:sand','4x minecraft:gravel'])
	
	 event.recipes.create.crushing([
	  'kubejs:sediment_paste',
	  Item.of('kubejs:storagium_nugget').withChance(0.1),
	  Item.of('kubejs:crushed_storagium_ore').withChance(0.01)],'undergarden:sediment')
	  event.replaceInput({output: 'tconstruct:nether_grout'}, 'minecraft:gravel', 'kubejs:sediment_paste')
	  
	  event.shapeless('tconstruct:sky_slime_ball',['create:dough','minecraft:cyan_dye'])
	  event.shapeless('tconstruct:ender_slime_ball',['create:dough','minecraft:popped_chorus_fruit'])
	  event.shapeless('tconstruct:blood_slime_ball',['create:dough','undergarden:blood_mushroom'])
	  event.shapeless('tconstruct:ichor_slime_ball',['create:dough','byg:embur_roots'])
	  
	  event.remove({id: 'tconstruct:tools/modifiers/ability/unbreakable'})
	  event.remove({id: 'tconstruct:smeltery/melting/metal/iron/ingot_6_16'})	
	  event.remove({id: 'tconstruct:smeltery/melting/metal/gold/powered_rail'})
	  event.remove({id: 'tconstruct:smeltery/melting/metal/iron/ingot_1'})
})






