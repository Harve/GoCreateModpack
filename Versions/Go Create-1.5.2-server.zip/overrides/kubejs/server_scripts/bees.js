// priority: 0

settings.logAddedRecipes = true
settings.logRemovedRecipes = true
settings.logSkippedRecipes = false
settings.logErroringRecipes = true


onEvent('recipes', event => {
	 event.shaped('9x minecraft:red_dye', [
	'   ',
	'EEE',
	'   '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	 event.shaped('9x minecraft:pink_dye', [
	'E  ',
	' E ',
	'  E'],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:purple_dye', [
	'  E',
	'  E',
	'  E'],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:yellow_dye', [
	'E E',
	' E ',
	'   '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:orange_dye', [
	'   ',
	'E E',
	' E '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:cyan_dye', [
	' E ',
	'E  ',
	'E  '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:light_blue_dye', [
	' E ',
	'E E',
	'   '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:light_gray_dye', [
	'   ',
	' EE',
	'E  '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:magenta_dye', [
	'E  ',
	' E ',
	'E  '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:lime_dye', [
	'  E',
	' E ',
	'E  '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:gray_dye', [
	' E ',
	'E  ',
	' E '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:blue_dye', [
	'  E',
	'  E',
	' E '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:green_dye', [
	'E  ',
	'E  ',
	' E '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:brown_dye', [
	'E  ',
	' EE',
	'   '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:white_dye', [
	'E  ',
	'EE ',
	'   '],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})
	event.shaped('9x minecraft:black_dye', [
	'   ',
	' EE',
	'  E'],{
		E: 'resourcefulbees:rgbee_honeycomb'
	
	})

	var beeMaterials =[['rose_quartz','create:rose_quartz'],['pigman','minecraft:glowstone'],['brass','create:brass_ingot'],['redstone','minecraft:redstone'],['diopside','blue_skies:diopside_gem'],['ancient','tconstruct:debris_nugget'],['andesite','minecraft:andesite'],['blaze','minecraft:blaze_rod'],['cell','refinedstorage:1k_storage_part'],['coal','minecraft:coal'],['copper','create:copper_ingot'],['creeper','minecraft:gunpowder'],['diamond','minecraft:diamond'],['emerald','minecraft:emerald'],['enchanting','minecraft:experience_bottle'],['ender','minecraft:ender_pearl'],['eternal_crystal','betterendforge:crystal_shards'],['fiery','twilightforest:fiery_ingot'],['go','kubejs:go_energy_green'],['gold','minecraft:gold_ingot'],['iron','minecraft:iron_ingot'],['lapis','minecraft:lapis_lazuli'],['lead','eidolon:lead_ingot'],['netherite','minecraft:netherite_ingot'],['nether_quartz','minecraft:quartz'],['skeleton','minecraft:bone'],['solar','solarflux:sp_2'],['storagium','kubejs:storagium_ingot'],['totem','minecraft:totem_of_undying'],['wire','createaddition:gold_spool'],['wither','minecraft:wither_skeleton_skull'],['zinc','create:zinc_ingot'],['zombie','minecraft:rotten_flesh']]
	beeMaterials.forEach((matieral)=>{
		var input =  'resourcefulbees:'+matieral[0]+'_honeycomb'

		event.recipes.createSequencedAssembly([
			Item.of('2x ' +matieral[1]).withChance(75.0),
			Item.of('8x resourcefulbees:wax').withChance(25.0),
			'4x minecraft:honey_bottle',
			'4x minecraft:honeycomb',
			'2x minecraft:honeycomb_block',
			
		  ],input, [
			event.recipes.createCutting(input, input).processingTime(60),
			event.recipes.createFilling(input, [input, Fluid.of('kubejs:enderic_acid',25)]),
			event.recipes.createDeploying(input, [input, 'createautomated:picker'])
		  ]).transitionalItem(input).loops(3)

		input = input +'_block'
		 
		event.recipes.createSequencedAssembly([
			Item.of('18x ' + matieral[1]).withChance(95.0),
			Item.of('16x resourcefulbees:wax').withChance(5.0),
			'16x minecraft:honey_bottle',
			'16x minecraft:honeycomb',
			'8x minecraft:honeycomb_block',
			
		  ],input, [
			event.recipes.createCutting(input, input).processingTime(240),
			event.recipes.createFilling(input, [input, Fluid.of('kubejs:enderic_acid',50)]),
			event.recipes.createDeploying(input, [input, 'createautomated:picker'])
		  ]).transitionalItem(input).loops(6)
	})

	event.remove({output: 'resourcefulbees:centrifuge'})
	event.remove({output: 'resourcefulbees:mechanical_centrifuge'})
	event.remove({output: 'resourcefulbees:centrifuge_controller'})
	event.remove({output: 'resourcefulbees:centrifuge_casing'})
	event.remove({output: 'resourcefulbees:elite_centrifuge_controller'})
	event.remove({output: 'resourcefulbees:elite_centrifuge_casing'})
})






