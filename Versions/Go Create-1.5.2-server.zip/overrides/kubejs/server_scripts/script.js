// priority: 0
var firstPlayer = true

settings.logAddedRecipes = true
settings.logRemovedRecipes = true
settings.logSkippedRecipes = false
settings.logErroringRecipes = true

console.info('Hello, World! (You will see this line every time server resources reload)')

onEvent('recipes', event => {
	const multiSmelt = (output, input) => {
		event.smelting(output, input)
		event.blasting(output, input)
	  }
	  const multiCook = (output, input) => {
		event.smelting(output, input)
		event.smoking(output, input)
	  }
	// Change recipes here
	event.remove({mod: 'ironjetpacks'})
	event.remove({id: 'twilightforest:uncrafting_table'})
	event.remove({id: 'cc:claim_block'})
	//UNDERGARDEN CHANGES
	event.remove({id:'undergarden:catalyst'})
	event.shaped('undergarden:catalyst', [
	'GLG',
	'LRL',
	'GLG'],{
		
	G: 'minecraft:gold_ingot',
	L: 'eidolon:lead_ingot',
	R: 'minecraft:diamond'
	})
	
	//CUSTOM ORE PROCESSING
		

	  
	  
	
	console.info('Thanks for downloading Go Create!')
	
	
	//IRONCHEST CHANGES
	event.remove({id:'ironchest:chests/gold_diamond_chest'})
	event.remove({id:'ironchest:chests/silver_diamond_chest'})
	event.shaped('ironchest:diamond_chest', [
	'GDG',
	'DCD',
	'GDG'],{
	G: '#forge:glass',
	D: 'minecraft:diamond',
	C: 'ironchest:gold_chest'})
	//EIDOLON CHANGES
	event.remove({id:'eidolon:pewter_blend'})
	event.shapeless('2x eidolon:pewter_blend',['create:crushed_lead_ore','create:crushed_iron_ore'])
	
	//OTHER CHANGES
	event.remove({id:'bountifulbaubles:gloves_digging_iron'})
	event.remove({id:'bountifulbaubles:gloves_digging_diamond'})
	event.shaped('bountifulbaubles:gloves_digging_iron', [
	' LD',
	' G ',
	'I  '],{
		I: 'minecraft:iron_ingot',
	G: 'alexsmobs:falconry_glove',
	D: 'create:mechanical_drill',
	L: 'transport:iron_rail'})

	event.shaped('bountifulbaubles:gloves_digging_diamond', [
	' DD',
	' GD',
	'A  '],{
		A: 'undergarden:forgotten_nugget',
	D: 'minecraft:diamond',
	G: 'bountifulbaubles:gloves_digging_iron'
	})
	//IRONJETPACKS CHANGE
	event.remove({id:'create_stuff_additions:encased_jet_recipe'})
	
	event.shaped('ironjetpacks:strap',[
	'SNS'],{
		S:'betterendforge:leather_stripe',
	N:'minecraft:iron_nugget'})
	event.shaped('ironjetpacks:copper_jetpack', [
	'SPS',
	'SJS',
	'T T'],{
		S: 'create:copper_sheet',
	P: 'ironjetpacks:copper_capacitor',
	J: 'ironjetpacks:strap',
	T: 'ironjetpacks:copper_thruster'})
	event.shaped('ironjetpacks:copper_capacitor', [
	'SZS',
	'SZS',
	'SZS'],{
		S: 'create:copper_sheet',
	
	Z: 'ironjetpacks:copper_cell'})
	event.shaped('ironjetpacks:copper_cell', [
	' T ',
	'SRS',
	' S '],{
		S: 'create:copper_sheet',
	T: 'createaddition:copper_rod',
	R: 'minecraft:redstone'})
	event.shaped('ironjetpacks:copper_thruster', [
	'SVS',
	'SPS',
	'W W'],{
		S: 'create:copper_sheet',
	V: 'create:copper_valve_handle',
	P: 'create:spout',
	W: 'createaddition:copper_wire'})
	event.recipes.create.mechanical_crafting('ironjetpacks:iron_jetpack',[
	' RCR ',
	' SPS ',
	' SJS ',
	' S S ',
	' T T '],{
		
		R:'createaddition:iron_rod',
		C:'kubejs:advanced_circuit',
		S:'create:iron_sheet',
		P:'ironjetpacks:iron_capacitor',
		J:'ironjetpacks:copper_jetpack',
		T:'ironjetpacks:iron_thruster'})
	event.shaped('ironjetpacks:iron_capacitor', [
	'TZT',
	'SZS',
	'SZS'],{
		S: 'create:iron_sheet',
	T:'createaddition:connector',
	Z: 'ironjetpacks:iron_cell'})
	event.shaped('ironjetpacks:iron_cell', [
	' W ',
	'SRS',
	' S '],{
		S: 'create:copper_sheet',
	W: 'createaddition:iron_wire',
	R: 'minecraft:redstone'})
	event.shaped('ironjetpacks:iron_thruster', [
	'SCS',
	'SZS',
	'S S'],{
		S: 'create:copper_sheet',
	Z: 'ironjetpacks:iron_cell',
	C: 'kubejs:integrated_circuit'
	})
	event.recipes.create.mechanical_crafting('ironjetpacks:gold_jetpack',[
	' RAR ',
	' PWP ',
	' SJS ',
	' S S ',
	' T T '],{
		
		R:'createaddition:gold_rod',
		A:'eidolon:gold_inlay',
		S:'create:golden_sheet',
		P:'ironjetpacks:gold_capacitor',
		W:'createaddition:gold_spool',
		J:'ironjetpacks:iron_jetpack',
		T:'ironjetpacks:gold_thruster'})
	event.shaped('ironjetpacks:gold_capacitor', [
	'TZT',
	'AZA',
	'SZS'],{
		S: 'create:golden_sheet',
	T:'minecraft:gold_ingot',
	A:'kubejs:advanced_circuit',
	Z: 'ironjetpacks:gold_cell'})
	event.shaped('ironjetpacks:gold_cell', [
	' W ',
	'SRS',
	' S '],{
		S: 'create:golden_sheet',
	W: 'createaddition:gold_wire',
	R: 'minecraft:redstone'})
	event.shaped('ironjetpacks:gold_thruster', [
	'SRS',
	'SJS',
	'S S'],{
		S: 'create:golden_sheet',
	R: 'minecraft:blaze_rod',
	J: 'twilightforest:encased_fire_jet'
	})
	
	event.recipes.create.mechanical_crafting('ironjetpacks:diamond_jetpack',[
	' AUA ',
	' DPD ',
	' DJD ',
	' D D ',
	' T T '],{
		
		U:'kubejs:storegalium_block',
		A:'kubejs:storegalium_ingot',
		D:'minecraft:diamond',
		P:'ironjetpacks:diamond_capacitor',
		J:'ironjetpacks:gold_jetpack',
		T:'ironjetpacks:diamond_thruster'})
	event.shaped('ironjetpacks:diamond_capacitor', [
	'DZD',
	'DZD',
	'DZD'],{
		D: 'minecraft:diamond',
	
	Z: 'ironjetpacks:diamond_cell'})
	event.shaped('ironjetpacks:diamond_cell', [
	' R ',
	'SDS',
	' R '],{
		S: 'minecraft:diamond',
	D: 'createaddition:diamond_grit',
	R: 'minecraft:redstone'})
	
	event.shaped('ironjetpacks:diamond_thruster', [
	' Z ',
	'SJS',
	'S S'],{
		S: 'minecraft:diamond',
	Z: 'ironjetpacks:diamond_cell',
	J: 'kubejs:storegalium_ingot'
	})
	event.recipes.create.mechanical_crafting('ironjetpacks:netherite_jetpack',[
	' SPS ',
	' SCS ',
	' SJS ',
	' S S ',
	' T T '],{
		
		C:'kubejs:microprocessor',
		S:'createdeco:netherite_sheet',
		P:'ironjetpacks:netherite_capacitor',
		J:'ironjetpacks:diamond_jetpack',
		T:'ironjetpacks:netherite_thruster'})
	event.shaped('ironjetpacks:netherite_capacitor', [
	'DZD',
	'DZD',
	'DZD'],{
		D: 'createdeco:netherite_sheet',
	
	Z: 'ironjetpacks:netherite_cell'})
	event.smithing('ironjetpacks:netherite_cell', 'ironjetpacks:diamond_cell', 'minecraft:netherite_ingot')
	event.shaped('ironjetpacks:netherite_thruster', [
	' Z ',
	'SJS',
	'S S'],{
		S: 'createdeco:netherite_sheet',
	Z: 'ironjetpacks:netherite_cell',
	J: 'betterendforge:eternal_crystal'
	})
	

	
	
	//BUILDING GADGETS CHANGES
	event.remove({id:'buildinggadgets:gadget_building'})
	 event.shaped('buildinggadgets:gadget_building', [
	'SDS',
	'SIS',
	'SBS'],{
		I: 'kubejs:integrated_circuit',
		D: 'minecraft:dispenser',
		S: 'create:iron_sheet',
		B: 'minecraft:stone_button'
	
	})
	event.remove({id:'buildinggadgets:gadget_exchanging'})
	 event.shaped('buildinggadgets:gadget_exchanging', [
	'SDS',
	'SIS',
	'SBS'],{
		I: 'kubejs:integrated_circuit',
		D: 'minecraft:dropper',
		S: 'create:iron_sheet',
		B: 'minecraft:stone_button'
	
	})
	event.remove({id:'buildinggadgets:gadget_copy_paste'})
	 event.shaped('buildinggadgets:gadget_copy_paste', [
	'SDS',
	'EIE',
	'SBS'],{
		I: 'kubejs:integrated_circuit',
		D: 'minecraft:dropper',
		S: 'create:iron_sheet',
		E: 'minecraft:emerald',
		B: 'minecraft:stone_button'
	
	})
	event.remove({id:'buildinggadgets:gadget_destruction'})
	 event.shaped('buildinggadgets:gadget_destruction', [
	'SDS',
	'PIP',
	'SBS'],{
		I: 'kubejs:integrated_circuit',
		D: 'minecraft:dispenser',
		S: 'create:iron_sheet',
		P: 'minecraft:ender_pearl',
		B: 'minecraft:stone_button'
	
	})
	
	
	//1.2 RECIPIES
	
	
	event.recipes.create.mixing('2x eidolon:pewter_ingot', [
	'minecraft:iron_ingot','#forge:ingots/lead']).heated()
	
	//1.3 ADDITIONS
	
	
	
	
	
	
	event.shaped('minecraft:chest',[
	'WWW',
	'W W',
	'WWW'],{
		
		W: '#minecraft:planks'
	
	})
	

 
	event.remove({id:'create:crushing/brass_block'})
	event.remove({id:'create:crushing/copper_block'})
	event.remove({id:'create:crushing/zinc_block'})
	//Slab recipes - Credit to Lytho from the KubeJS Discord!
	 event.forEachRecipe({ type: 'minecraft:crafting_shaped', output: '#minecraft:slabs' }, r => {
    event.shaped(r.inputItems[0], ["A", "A"], { A: r.outputItems[0].withCount(1) });
  });
  
  
	event.remove({id:'witherutilsexp:xpsucker'})
	event.shaped('witherutilsexp:xpsucker',[
	'   ',
	' P ',
	' D '],{
		
		P: 'minecraft:light_weighted_pressure_plate',
		D: 'create:item_drain'
		
	
	})
	 
	
	 
	
	  
	
	  
	
	event.remove({mod:'enderstorage'})
	event.shaped('enderstorage:ender_chest',[
	'RWR',
	'SCS',
	'RTR'],{
		R: 'minecraft:blaze_rod',
		S: 'betterendforge:ender_shard',
		T: 'betterendforge:eternal_crystal',
		W: '#forge:wool',
		C: 'ironchest:obsidian_chest'
		
	
	})
	event.shaped('enderstorage:ender_tank',[
	'RWR',
	'SCS',
	'RTR'],{
		R: 'minecraft:blaze_rod',
		S: 'betterendforge:ender_shard',
		T: 'betterendforge:eternal_crystal',
		W: '#forge:wool',
		C: 'create:fluid_tank'
		
	
	})
	
	 
	 var upgradePath = ['obsidian','iron','gold','diamond','emerald']
	 for (let i = 1; i < upgradePath.length; i++) {
		  event.replaceInput({output: 'storagedrawers:'+upgradePath[i]+'_storage_upgrade'}, 'storagedrawers:upgrade_template', 'storagedrawers:'+upgradePath[i-1]+'_storage_upgrade')
		}
	  event.replaceInput({mod:'storagedrawers'}, '#forge:rods/wooden', '#forge:rods/copper')
	  
	  event.remove({id:'storagedrawers:compacting_drawers_3'})
	  event.remove({id:'storagedrawers:controller'})
	  event.remove({id:'storagedrawers:controller_slave'})
	  event.recipes.create.mechanical_crafting('storagedrawers:controller',[
	
	'SSSSS',
	'TDADT',
	'SSSSS'],{
		S:'minecraft:stone',
		T:'create:redstone_contact',
		D:'minecraft:diamond',
		A:'#storagedrawers:drawers'
	})
	event.recipes.create.mechanical_crafting('storagedrawers:controller_slave',[
	
	'SSSSS',
	'TGAGT',
	'SSSSS'],{
		S:'minecraft:stone',
		T:'create:redstone_contact',
		G:'minecraft:gold_ingot',
		A:'#storagedrawers:drawers'
	})
	event.shaped('storagedrawers:compacting_drawers_3',[
	'SSS',
	'PAP',
	'SSS'],{
		S:'minecraft:stone',
		P: 'create:mechanical_press',
		A:'#storagedrawers:drawers'
		
		
	
	})
	
	
	
	
	
	
	
	   
	   
	
	
	
	var backpackTiers = ['iron','gold','diamond','netherite']
	
	var block
	 for (let i = 0; i < upgradePath.length-1; i++){
		  event.remove({id: 'sophisticatedbackpacks:stack_upgrade_tier_'+(i+1).toString()})
		  switch(i){
			  case 0:
				  block = 'minecraft:iron_block'
				  upgrade ='sophisticatedbackpacks:upgrade_base'
				  break
			  case 1:
				  block = 'kubejs:storagium_block'
				  upgrade = 'sophisticatedbackpacks:stack_upgrade_tier_'+(i).toString()
				  break
			  case 2:
				  block = 'kubejs:storegalium_block'
				   upgrade = 'sophisticatedbackpacks:stack_upgrade_tier_'+(i).toString()
				  break
			  case 3:
				  block = 'kubejs:gotopium_block'
				   upgrade = 'sophisticatedbackpacks:stack_upgrade_tier_'+(i).toString()
				  break
		  }
			  event.recipes.create.mechanical_crafting('sophisticatedbackpacks:stack_upgrade_tier_'+(i+1).toString(),[
				'  I  ',
				' BIB ',
				'IIGII',
				' BIB ',
				'  I  '],{
				I:'minecraft:'+backpackTiers[i]+'_block',
				G: upgrade,
				B: block})
					}
		  
		  var pickingRecipes = [['create:copper_nugget','twilightforest:torchberries'],['kubejs:storagium_nugget','undergarden:gloomgourd'],['undergarden:regalium_nugget','undergarden:glowing_kelp']]
		  pickingRecipes.forEach((pick)=>{
		  event.recipes.create.deploying(Item.of(pick[0]).withChance(0.2),[pick[1],'createautomated:picker'])
		  event.custom({
  "type": "createautomated:picking",
  "results": [
    {
      "item": pick[0],
      "chance": 0.2
    }
  ],
  "ingredient": {
    "item": pick[1]
  }
})
event.shaped('2x solarflux:sp_3', [
	'LLL',
	'PCP',
	'PSP'],{
	C: 'kubejs:integrated_circuit',
    S: 'create:iron_sheet',	
	L: 'solarflux:photovoltaic_cell_2',
	P: 'solarflux:sp_2'
	})
	event.shaped('2x solarflux:sp_4', [
	'LLL',
	'PCP',
	'PSP'],{
	C: 'kubejs:advanced_circuit',
    S: 'create:brass_sheet',	
	L: 'solarflux:photovoltaic_cell_3',
	P: 'solarflux:sp_3'
	})
	event.shaped('4x solarflux:sp_5', [
	'LLL',
	'PCP',
	'PSP'],{
	C: 'kubejs:microprocessor',
    S: 'create:brass_block',	
	L: 'solarflux:photovoltaic_cell_4',
	P: 'solarflux:sp_4'
	})
})
event.shapeless('minecraft:trapped_chest',['minecraft:chest','minecraft:tripwire_hook'])

event.replaceInput({output:'sophisticatedbackpacks:upgrade_base'},'minecraft:iron_ingot','create:brass_ingot')
event.remove({id:'magicfeather:magicfeather'})
event.remove({id:'waystones:warp_stone'})

event.custom({
	"type": "betterendforge:infusion",
  "input": 
  {
     "item": "twilightforest:raven_feather"
  },
  "output": "magicfeather:magicfeather",
  "time": 250,
  "catalysts": [
    {
      "item": "minecraft:elytra",
      "index": 0
    },
    {
      "item": "betterendforge:eternal_crystal",
      "index": 2
    },
    {
      "item": "minecraft:elytra",
      "index": 4
    },
    {
      "item": "betterendforge:eternal_crystal",
      "index": 6
    },
    {
      "item": "eidolon:unholy_symbol",
      "index": 1
    },
    {
      "item": "eidolon:unholy_symbol",
      "index": 3
    },
    {
      "item": "eidolon:unholy_symbol",
      "index": 5
    },
    {
      "item": "eidolon:unholy_symbol",
      "index": 7
    }
  ]
})
event.custom({
	"type": "betterendforge:infusion",
  "input": 
  {
     "item": "blue_skies:diopside_gem"
  },
  "output": "waystones:warp_stone",
  "time": 250,
  "catalysts": [
    {
      "item": "betterendforge:eternal_crystal",
      "index": 0
    },
    {
      "item": "betterendforge:eternal_crystal",
      "index": 2
    },
    {
      "item": "betterendforge:eternal_crystal",
      "index": 4
    },
    {
      "item": "betterendforge:eternal_crystal",
      "index": 6
    },
    {
      "item": "kubejs:enderate_crystal",
      "index": 1
    },
    {
      "item": "kubejs:enderate_crystal",
      "index": 3
    },
    {
      "item": "kubejs:enderate_crystal",
      "index": 5
    },
    {
      "item": "kubejs:enderate_crystal",
      "index": 7
    }
  ]
})
event.recipes.create.mixing(Item.of('blue_skies:zeal_lighter', {Damage:125}), [
	'kubejs:powder_of_ender','#forge:gems/quartz','#forge:gems/prismarine']).heated()

	event.recipes.create.splashing(['blue_skies:turquoise_stone'],['undergarden:shiverstone'])
    event.recipes.create.splashing(['blue_skies:lunar_stone'],['minecraft:crying_obsidian'])
	event.recipes.create.splashing(['upgrade_aquatic:driftwood_log'],['#minecraft:logs'])
})






events.listen('player.tick', function (event) {
  let world = event.player.getWorld().getDimension().toString()
  if(world == "gocreate:gotopia"){
   if(firstPlayer){
   event.server.runCommand(`function structures:density/abundant`)
	event.server.runCommand(`function structures:clock/normal`)
	event.server.runCommand(`function generator:generate`)
	event.server.runCommand(`execute as @p run function structures:spread/gen_reset`)
   firstPlayer = false
   }}
});



