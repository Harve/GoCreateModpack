// priority: 0

settings.logAddedRecipes = true
settings.logRemovedRecipes = true
settings.logSkippedRecipes = false
settings.logErroringRecipes = true


onEvent('recipes', event => {
	const multiSmelt = (output, input) => {
		event.smelting(output, input)
		event.blasting(output, input)
	  }
	  const multiCook = (output, input) => {
		event.smelting(output, input)
		event.smoking(output, input)
	  }
	    
	  event.shaped('kubejs:storagium_ingot', [
	'NNN',
	'NNN',
	'NNN'],{
		
	
	N: 'kubejs:storagium_nugget'
	})
	 //Dust Washing
	 var metalTypes = ['create:brass','minecraft:iron','create:copper','create:zinc','eidolon:lead','kubejs:storagium','minecraft:gold','undergarden:cloggrum','tconstruct:cobalt','undergarden:froststeel','undergarden:regalium','betterendforge:thallasium','undergarden:utherium','kubejs:gotopium']
	 var stoneTypes = ['minecraft:cobblestone','undergarden:depthrock','minecraft:netherrack','minecraft:end_stone']
	 var stoneNum = 0
	 metalTypes.forEach((metalID) => {
		 var metalName = metalID.substring(metalID.indexOf(":")+1,metalID.length)
		 if(metalID == 'undergarden:utherium'){
			 event.recipes.create.splashing(['19x '+metalID+'_chunk',Item.of('11x '+metalID+'_chunk').withChance(0.5)],['kubejs:impure_'+metalName+'_dust'])
		 }else{
			 event.recipes.create.splashing(['19x '+metalID+'_nugget',Item.of('11x '+metalID+'_nugget').withChance(0.5)],['kubejs:impure_'+metalName+'_dust']) }
	
	//Acid Mixing
	if(metalID.indexOf("create") != -1 || metalID.indexOf("minecraft") != -1|| metalID.indexOf("eidolon") != -1){
		if(metalName == 'brass' ){
			event.recipes.create.mixing('kubejs:impure_'+metalName+'_dust', [
	  'create:crushed_'+metalName,
	  Fluid.of('kubejs:enderic_acid',250)])
		}else{
	event.recipes.create.mixing('kubejs:impure_'+metalName+'_dust', [
	  'create:crushed_'+metalName+'_ore',
	  Fluid.of('kubejs:enderic_acid',250)
	])}} else{
		event.recipes.create.mixing('kubejs:impure_'+metalName+'_dust', [
	  'kubejs:crushed_'+metalName+'_ore',
	  Fluid.of('kubejs:enderic_acid',250)])
	}
	
	if(!(metalID.indexOf("create") != -1 || metalID.indexOf("minecraft") != -1|| metalID.indexOf("eidolon") != -1 )){
		switch(metalID.substring(0,metalID.indexOf(":"))){
			case "undergarden":
            case "kubejs":
                if (metalName == "gotopium") {
                    stoneNum = 0
                } else {
                    stoneNum = 1
                }
			   break
			case "tconstruct":
			   stoneNum = 2
			   break
			case "betterendforge":
			   stoneNum = 3
		break}
		event.recipes.create.crushing([
	  'kubejs:crushed_'+metalName+'_ore',
	  Item.of('2x kubejs:crushed_'+metalName+'_ore').withChance(0.3),
	  Item.of(stoneTypes[stoneNum]).withChance(0.1)],metalID+'_ore')
	  multiSmelt(metalID+'_ingot','kubejs:crushed_'+metalName+'_ore')
	  if(metalID == 'undergarden:utherium'){
			 event.recipes.create.splashing(['10x '+metalID+'_chunk',Item.of('5x '+metalID+'_chunk').withChance(0.5)],['kubejs:crushed_'+metalName+'_ore'])
		 }else{
			 event.recipes.create.splashing(['10x '+metalID+'_nugget',Item.of('5x '+metalID+'_nugget').withChance(0.5)],['kubejs:crushed_'+metalName+'_ore']) }
	 
	 }})
	 
	 //custom ore smelting
    multiSmelt( 'kubejs:storagium_ingot','#forge:ores/storagium')
    multiSmelt('kubejs:gotopium_ingot', '#forge:ores/gotopium')
    event.recipes.create.crushing([
        'kubejs:crushed_storagium_ore',
        Item.of('2x kubejs:crushed_storagium_ore').withChance(0.3),
        Item.of(stoneTypes[stoneNum]).withChance(0.1)], 'kubejs:stone_storagium_ore')
	  
	  //custom metal
	  var customMetals = ['storagium','storegalium','gotopium']
	customMetals.forEach((metal) =>{
	event.shapeless('9x kubejs:'+metal+'_nugget',['kubejs:'+metal+'_ingot'])
	 event.shapeless('9x kubejs:'+metal+'_ingot',['kubejs:'+metal+'_block'])
	 
	  event.shaped('kubejs:'+metal+'_ingot', [
	'NNN',
	'NNN',
	'NNN'],{
		
	
	N: 'kubejs:'+metal+'_nugget'
	})
	 event.shaped('kubejs:'+metal+'_block', [
	'NNN',
	'NNN',
	'NNN'],{
		
	
	N: 'kubejs:'+metal+'_ingot'
	})
	})
	  
	  //Imporium recipes
	  event.recipes.create.pressing('kubejs:storegalium_sheet',['kubejs:storegalium_ingot'])
	event.recipes.create.pressing('kubejs:gotopium_sheet',['kubejs:gotopium_ingot'])
	event.recipes.create.mixing('2x kubejs:storegalium_ingot', [
	'#forge:ingots/regalium','#forge:ingots/storagium']).heated()
	event.recipes.create.mixing('2x kubejs:crushed_storegalium', [
	'kubejs:crushed_regalium_ore','kubejs:crushed_storagium_ore']).heated()
	 multiSmelt('kubejs:storegalium_ingot','kubejs:crushed_storegalium')
	 event.recipes.create.mixing('kubejs:impure_storegalium_dust', [
	  'kubejs:crushed_storegalium',
	  Fluid.of('kubejs:enderic_acid',250)])
	   event.recipes.create.splashing(['10x kubejs:storegalium_nugget',Item.of('5x kubejs:storegalium_nugget').withChance(0.5)],['kubejs:crushed_storegalium'])
	   event.recipes.create.splashing(['19x kubejs:storegalium_nugget',Item.of('11x kubejs:storegalium_nugget').withChance(0.5)],['kubejs:impure_storegalium_dust'])
	   
	   
	   //Enderic Acid recipes
	   event.recipes.create.sequenced_assembly([
  Item.of('kubejs:powder_of_ender').withChance(100.0)], 'minecraft:ender_eye', [
  event.recipes.create.cutting('minecraft:ender_eye', ['minecraft:ender_eye']).processingTime(60),
  event.recipes.create.pressing('minecraft:ender_eye',['minecraft:ender_eye'])
]).transitionalItem('minecraft:ender_eye').loops(12)


  event.recipes.create.mixing('kubejs:enderate_crystal', ['kubejs:powder_of_ender',Fluid.of('kubejs:lumecorn_oil', 1000)]).superheated().processingTime(1200)
  
	event.recipes.create.mixing(Fluid.of('kubejs:enderic_acid',250), [
	  'kubejs:enderate_crystal',
	  Fluid.of('minecraft:water',500)
	]).superheated()
	
	event.recipes.create.mixing(Fluid.of('kubejs:enderic_acid',750), [
	  'betterendforge:ender_shard',
	  Fluid.of('minecraft:water',1000)
	]).superheated()
	
	event.recipes.create.crushing(
	  
	  Item.of('betterendforge:ender_dust').withChance(0.66)
	  ,'betterendforge:ender_shard')


	  event.recipes.create.compacting([Fluid.of('kubejs:lumecorn_oil', 50), Item.of('betterendforge:lumecorn_seed').withChance(0.75)] ,'betterendforge:lumecorn_rod')
	  event.recipes.create.compacting([Fluid.of('kubejs:lumecorn_oil', 40), Item.of('betterendforge:bulb_vine_seed').withChance(0.75)] ,'betterendforge:glowing_bulb')
	  event.recipes.create.compacting([Fluid.of('kubejs:lumecorn_oil', 80), Item.of('betterendforge:blue_vine_seed').withChance(0.75)] ,'betterendforge:blue_vine_lantern')
	  event.recipes.create.compacting([Fluid.of('kubejs:lumecorn_oil', 100),Item.of('betterendforge:end_lily_seed').withChance(0.75)] ,'betterendforge:end_lily_leaf_dried')
	  event.recipes.create.compacting([Fluid.of('kubejs:lumecorn_oil', 10)],'minecraft:popped_chorus_fruit')

	  
	})






