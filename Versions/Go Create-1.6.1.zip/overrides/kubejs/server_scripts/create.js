// priority: 0

settings.logAddedRecipes = true
settings.logRemovedRecipes = true
settings.logSkippedRecipes = false
settings.logErroringRecipes = true


onEvent('recipes', event => {
	//CREATE CHANGES
	event.recipes.create.mechanical_crafting('kubejs:integrated_circuit',[
	
	'  L  ',
	'DDADD',
	' NNN '],{
		L:'kubejs:lapis_sheet',
		N:'minecraft:gold_nugget',
		D:'minecraft:redstone',
		A:'create:polished_rose_quartz'
	})
	event.recipes.create.pressing('kubejs:lapis_sheet',['minecraft:lapis_lazuli'])
	event.shapeless('kubejs:blazing_alloy',['minecraft:blaze_powder','create:powdered_obsidian'])
	event.shapeless('2x kubejs:blazing_sugar',['minecraft:sugar','kubejs:blazing_alloy'])
	event.remove({id:'create:compacting/blaze_cake'})
	event.recipes.create.compacting('create:blaze_cake_base',['#forge:eggs','kubejs:blazing_sugar','create:cinder_flour'])
	//CREATE CRAFTS&ADDITIONS CHANGES
	event.remove({id:'createaddition:crafting/connector_1'})
	event.shaped('4x createaddition:connector', [
	' B ',
	'ARA',
	'ARA'],{
		
	A: 'create:andesite_alloy',
	B: 'create:copper_nugget',
	R: 'createaddition:copper_rod'
	})
	event.remove({id:'createaddition:crafting/furnace_burner'})
	event.remove({id:'createaddition:crafting/charger'})
	event.shaped('createaddition:charger',[
	'B B',
	'CNC',
	'SAS'],{
		A:'kubejs:advanced_circuit',
		B: 'create:copper_nugget',
		C:'createaddition:capacitor',
		S:'create:brass_sheet',
	N:'create:brass_casing'})
	event.remove({id:'createaddition:mechanical_crafting/accumulator'})
	event.recipes.create.mechanical_crafting('createaddition:accumulator',[
	' C C ',
	'SPWPS',
	'SPBPS',
	'SPAPS'],{
		A:'kubejs:advanced_circuit',
		P:'createaddition:capacitor',
		W:'createaddition:gold_spool',
		C:'createaddition:connector',
		S:'create:brass_sheet',
	B:'create:brass_casing'})
	event.remove({id:'createaddition:mechanical_crafting/alternator'})
	event.recipes.create.mechanical_crafting('createaddition:alternator',[
	'  F  ',
	'SWWWS',
	'SWRWS',
	'SWPWS',
	'SWAWS'],{
		A:'kubejs:advanced_circuit',
		P:'createaddition:capacitor',
		W:'createaddition:copper_spool',
		R:'createaddition:iron_rod',
		S:'create:iron_sheet',
	F:'create:shaft'})
	event.remove({id:'createaddition:crafting/crude_burner'})
	event.shaped('createaddition:crude_burner',[
	' S ',
	'CTC',
	'CBC'],{
		
		B: 'minecraft:blast_furnace',
		
		S:'create:spout',
		T:'create:fluid_tank',
	C:'create:copper_casing'})
	//CUSTOM CREATE ADDITIONS
	
	event.shaped('4x kubejs:silicon_blend', [
	'QEQ',
	'ERE',
	'QEQ'],{
		
	E: 'byg:end_sand',
	Q: 'byg:quartzite_sand',
	R: 'create:refined_radiance'
	})
	
	event.recipes.create.mixing(Fluid.of('kubejs:molten_silicon',100),[
	'kubejs:silicon_blend']).superheated()
	
	event.recipes.create.filling('kubejs:silicon_wafer', [
	  'minecraft:nether_star',
	  Fluid.of('kubejs:molten_silicon')
	])
	
	event.recipes.create.mechanical_crafting('kubejs:microprocessor',[
	
	'  P  ',
	'HCSCH',
	' RRR '],{
		P:'createdeco:netherite_sheet',
		H:'create:shadow_steel',
		C:'kubejs:advanced_circuit',
		S:'kubejs:silicon_wafer',
	R:'betterendforge:thallasium_ingot'})
	
	event.recipes.create.mechanical_crafting('kubejs:advanced_circuit',[
	
	' TTT ',
	'QCACQ',
	' WWW '],{
		T:'create:electron_tube',
		Q:'minecraft:quartz',
		C:'kubejs:integrated_circuit',
		A:'createaddition:capacitor',
	W:'createaddition:gold_wire'})
	
	
	 event.remove({mod:'createchunkloading'})
	 event.shaped('createchunkloading:chunk_loader', [
	'GEG',
	'EIE',
	'GEG'],{
		I: 'kubejs:advanced_circuit',
		G: 'minecraft:glass',
		E: 'minecraft:emerald'
	
	})
	
	event.remove({id:'createautomated:ore_extractor'})
	event.recipes.create.mechanical_crafting('createautomated:ore_extractor',[
	
	'CWC',
	'BPB',
	'BSB',
	'B B'],{
		S:'create:shaft',
		P:'create:precision_mechanism',
		C:'create:brass_casing',
		B:'create:brass_ingot',
	W:'create:cogwheel'})


	
	event.remove({id:'create:pressing/zinc_sheet'})
	
	event.recipes.create.splashing([Item.of('minecraft:quartz').withChance(0.66)],['byg:quartzite_sand'])
	
	event.recipes.createautomated.extracting("kubejs:storagium_node", "kubejs:storagium_ore_piece").drillDamage(2).ore(2,5).requiredProgressSeconds(4,128) 
	event.recipes.createautomated.extracting("kubejs:regalium_node", "kubejs:regalium_ore_piece").drillDamage(2).ore(1,5).requiredProgressSeconds(6,128) 
	event.recipes.createautomated.extracting("kubejs:cobalt_node", "kubejs:cobalt_ore_piece").drillDamage(8).ore(1,3).requiredProgressSeconds(10,128) 
	event.recipes.createautomated.extracting("kubejs:redstone_node", "minecraft:redstone").drillDamage(1).ore(2).requiredProgressSeconds(2,128)
	event.recipes.createautomated.extracting("minecraft:ancient_debris", "tconstruct:debris_nugget").drillDamage(10).ore(1).requiredProgressSeconds(60,128)
	
	 event.recipes.create.sequenced_assembly([
	  Item.of('createautomated:drill_head').withChance(100.0)], 'kubejs:drill_sand_cast', [
	  event.recipes.create.filling('kubejs:incomplete_drill_sand_cast', ['kubejs:incomplete_drill_sand_cast',Fluid.of('tconstruct:molten_iron', 1000)])
	  ]).transitionalItem('kubejs:incomplete_drill_sand_cast').loops(4)
	  
	  event.recipes.create.sequenced_assembly([
	  Item.of('createautomated:drill_head').withChance(100.0)], 'kubejs:drill_red_sand_cast', [
	  event.recipes.create.filling('kubejs:incomplete_drill_red_sand_cast', ['kubejs:incomplete_drill_red_sand_cast',Fluid.of('tconstruct:molten_iron', 1000)])
	  ]).transitionalItem('kubejs:incomplete_drill_red_sand_cast').loops(4)
	  

	  event.recipes.create.compacting(['kubejs:drill_sand_cast','createautomated:drill_head'],['createautomated:drill_head','tconstruct:blank_sand_cast'])
	  event.recipes.create.compacting(['kubejs:drill_red_sand_cast','createautomated:drill_head'],['createautomated:drill_head','tconstruct:blank_red_sand_cast'])	
	  event.remove({id:'createautomated:mixing/iron_ingot_from_pieces'})	
	  event.remove({id:'createautomated:mixing/gold_ingot_from_pieces'})	
	  event.remove({id:'createautomated:mixing/copper_ingot_from_pieces'})	
	  event.remove({id:'createautomated:mixing/zinc_ingot_from_pieces'})	
	  event.remove({id:'createautomated:mixing/lapis_gluing'})	

	  event.recipes.create.mixing('kubejs:storagium_ingot',['9x kubejs:storagium_ore_piece']).heated()
	  event.recipes.create.mixing('tconstruct:cobalt_ingot',['9x kubejs:cobalt_ore_piece']).heated()
	  event.recipes.create.mixing('undergarden:regalium_ingot',['9x kubejs:regalium_ore_piece']).heated()
	  event.recipes.create.mixing('minecraft:iron_ingot',['9x createautomated:iron_ore_piece']).heated()
	  event.recipes.create.mixing('minecraft:gold_ingot',['9x createautomated:gold_ore_piece']).heated()
	  event.recipes.create.mixing('create:zinc_ingot',['9x createautomated:zinc_ore_piece']).heated()
	  event.recipes.create.mixing('minecraft:lapis_lazuli',['9x createautomated:gold_ore_piece','#forge:slimeballs'])
	  event.recipes.create.mixing('create:copper_ingot',['9x createautomated:copper_ore_piece']).heated()
	 
	  
	  event.recipes.create.mechanical_crafting('kubejs:gotopium_drillhead',[
	    '  I  ',
		'SGGGS',
		' SGS ',
		' SIS ',
		'  S  '],{
			S:'kubejs:gotopium_sheet',
			G:'kubejs:gotopium_block',
			I:'kubejs:gotopium_ingot'
	})

	
	  event.recipes.create.mixing('kubejs:storagium_ingot', ['6x kubejs:storagium_ore_piece',Fluid.of('kubejs:enderic_acid',100)]).superheated()
	  event.recipes.create.mixing('tconstruct:cobalt_ingot', ['6x kubejs:cobalt_ore_piece',Fluid.of('kubejs:enderic_acid',100)]).superheated()
	  event.recipes.create.mixing('undergarden:regalium_ingot', ['6x kubejs:regalium_ore_piece',Fluid.of('kubejs:enderic_acid',100)]).superheated()
	  event.recipes.create.mixing('minecraft:iron_ingot', ['6x createautomated:iron_ore_piece',Fluid.of('kubejs:enderic_acid',100)]).superheated()
	  event.recipes.create.mixing('minecraft:gold_ingot', ['6x createautomated:gold_ore_piece',Fluid.of('kubejs:enderic_acid',100)]).superheated()
	  event.recipes.create.mixing('create:zinc_ingot', ['6x createautomated:zinc_ore_piece',Fluid.of('kubejs:enderic_acid',100)]).superheated()
	  event.recipes.create.mixing('create:copper_ingot', ['6x createautomated:copper_ore_piece',Fluid.of('kubejs:enderic_acid',100)]).superheated()
})







